﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DataLayer.ViewModels
{
    public class ProductCommentViewModel
    {
        public int CommentID { get; set; }
        public int ProductID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        [Display(Name = "پیام خود")]
        [Required(ErrorMessage = "لطفا {0} را وارد کنید")]
        [DataType(DataType.MultilineText)]
        public string Comment { get; set; }
        public System.DateTime CreateDate { get; set; }
        public Nullable<int> ParentID { get; set; }
        public bool IsValid { get; set; }
    }
}
