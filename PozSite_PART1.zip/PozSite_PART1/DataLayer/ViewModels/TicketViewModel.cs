﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DataLayer.ViewModels
{
    public class TicketViewModel
    {
        public int TicketID { get; set; }
        [Display(Name = "تیتر")]
        [Required(ErrorMessage = "لطفا {0} را وارد کنید")]
        [MaxLength(200, ErrorMessage = "تعداد کاراکتر بیشتر است")]
        [MinLength(3, ErrorMessage = "تعداد کاراکتر کم است")]
        public string Title { get; set; }
        [Display(Name = "توضیحات")]
        [Required(ErrorMessage = "لطفا {0} را وارد کنید")]
        [MaxLength(800, ErrorMessage = "تعداد کاراکتر بیشتر است")]
        [MinLength(3, ErrorMessage = "تعداد کاراکتر کم است")]
        [DataType(DataType.MultilineText)]
        public string Body { get; set; }
        public string Image { get; set; }
        public string Email { get; set; }
        public string UserName { get; set; }
        public Nullable<int> UserID { get; set; }
        public bool IsAnswered { get; set; }
        public bool IsLoggedin { get; set; }
        public bool IsAdmin { get; set; }
        public System.DateTime DateSubmited { get; set; }

    }
}
