﻿namespace DataLayer.ViewModels
{
    public class SumPriceViewModel
    {
        public int Discount { get; set; }
        public int DiscountId { get; set; }
        public int PriceSum { get; set; }
    }
}
