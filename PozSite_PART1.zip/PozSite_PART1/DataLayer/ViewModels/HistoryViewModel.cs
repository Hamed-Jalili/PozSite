﻿using System;

namespace DataLayer.ViewModels
{
    public class HistoryViewModel
    {
        public int OrderId { get; set; }
        public int Count { get; set; }
        public int Price { get; set; }
        public DateTime Date { get; set; }
        public bool IsFinaly { get; set; }
        public string UserName { get; set; }
        
    }
}
