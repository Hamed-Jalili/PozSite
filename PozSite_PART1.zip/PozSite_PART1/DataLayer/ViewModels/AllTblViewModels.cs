﻿using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace DataLayer.ViewModels
{
    public class AdViewModels
    {
        public int AdID { get; set; }
        [Display(Name = "عکس")]
        [Required(ErrorMessage = "لطفا {0} را وارد کنید")]
        public string Image { get; set; }
        [Display(Name = "آدرس لینک")]
        [Required(ErrorMessage = "لطفا {0} را وارد کنید")]
        [MaxLength(800, ErrorMessage = "تعداد کاراکتر بیشتر است")]
        [MinLength(2, ErrorMessage = "تعداد کاراکتر کم است")]
        public string Link { get; set; }
        [Display(Name = "موقعیت")]
        public int PositionId { get; set; }
    }
    public class BlogViewModels
    {
        public int BlogID { get; set; }
        [Display(Name = "دسته")]
        [Required(ErrorMessage = "لطفا {0} را وارد کنید")]
        //[Range(typeof(decimal), "0", "79228162514264337593543950335")]
        public int GroupID { get; set; }
        [Display(Name = "موضوع")]
        [Required(ErrorMessage = "لطفا {0} را وارد کنید")]
        [MaxLength(100, ErrorMessage = "تعداد کاراکتر بیشتر است")]
        [MinLength(5, ErrorMessage = "تعداد کاراکتر کم است")]
        public string Title { get; set; }
        [Display(Name = "متن")]
        [Required(ErrorMessage = "لطفا {0} را وارد کنید")]
        [MinLength(5, ErrorMessage = "تعداد کاراکتر کم است")]
        [DataType(DataType.MultilineText)]
        [AllowHtml]
        public string HtmlBody { get; set; }
        [Display(Name = "عکس")]
        public string MainImage { get; set; }
        public System.DateTime DatePosted { get; set; }
        [Display(Name = "پیشنهادی")]
        public bool IsSuggested { get; set; }

    }
 
}
