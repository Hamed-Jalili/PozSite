﻿using System.ComponentModel.DataAnnotations;

namespace DataLayer.ViewModels
{
    public class OnlineOrderViewModel
    {
        public int OrderID { get; set; }
        [Display(Name = "موضوع")]
        [Required(ErrorMessage = "لطفا {0} را وارد کنید")]
        [MaxLength(200, ErrorMessage = "تعداد کاراکتر بیشتر است")]
        [MinLength(3, ErrorMessage = "تعداد کاراکتر کم است")]
        public string Title { get; set; }
        [Display(Name = "متن خود")]
        [Required(ErrorMessage = "لطفا {0} را وارد کنید")]
        [DataType(DataType.MultilineText)]
        [MaxLength(800, ErrorMessage = "تعداد کاراکتر بیشتر است")]
        [MinLength(3, ErrorMessage = "تعداد کاراکتر کم است")]
        public string Body { get; set; }
        public System.DateTime DateSubmited { get; set; }
        public int UserID { get; set; }
    }
}
