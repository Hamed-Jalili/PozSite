﻿using System;

namespace DataLayer.ViewModels
{
    internal class JsonPropertyAttribute : Attribute
    {
    }
}