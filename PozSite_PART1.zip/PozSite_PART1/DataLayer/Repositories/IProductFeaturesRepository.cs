﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface IProductFeaturesRepository
    {
        List<Product_Features> GetAllProductFeatures();
        Product_Features GetProductFeatureById(int productFeatureId);
        bool InsertProductFeature(Product_Features productFeature);
        bool UpdateProductFeature(Product_Features productFeature);
        bool DeleteProductFeature(Product_Features productFeature);
        bool DeleteProductFeature(int productFeatureId);
        void Save();
    }
}
