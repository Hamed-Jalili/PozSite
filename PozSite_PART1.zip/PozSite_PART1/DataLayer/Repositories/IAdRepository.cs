﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    public interface IAdRepository
    {
        List<Ad> GetAllAds();
        Ad GetAdsByRandoms();
        Ad GetAdById(int adId);
        bool InsertAd(Ad ad);
        bool UpdateAd(Ad ad);
        bool DeleteAd(Ad ad);
        bool DeleteAd(int adId);
        void Save();
    }
}
