﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface IProductsRepository
    {
        List<Products> GetAllProducts();
        IEnumerable<Products> GetCusstomersByFilter(string parameter);
        List<Products> GetNameProducts(string filter = "");
        List<Products> GetLastProducts(int take);
        Products GetProductById(int productId);
        bool InsertProduct(Products product);
        bool UpdateProduct(Products product);
        bool DeleteProduct(Products product);
        bool DeleteProduct(int productId);
        int GetProductIdByName(string name);
        string GetProductNameById(int productId);
        void Save();
    }
}
