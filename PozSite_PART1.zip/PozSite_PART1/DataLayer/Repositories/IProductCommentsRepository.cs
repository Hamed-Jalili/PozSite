﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface IProductCommentsRepository
    {
        List<Product_Comments> GetAllProductComments();
        Product_Comments GetProductCommentById(int productCommentId);
        bool InsertProductComment(Product_Comments productComment);
        bool UpdateProductComment(Product_Comments productComment);
        bool DeleteProductComment(Product_Comments productComment);
        bool DeleteProductComment(int productCommentId);
        void Save();
        void Dispose();
    }
}
