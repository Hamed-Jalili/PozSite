﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface IFeaturesRepository
    {
        List<Features> GetAllFeatures();
        Features GetFeaturesById(int featureId);
        bool InsertFeatures(Features feature);
        bool UpdateFeatures(Features feature);
        bool DeleteFeatures(Features feature);
        bool DeleteFeatures(int featureId);
        void Save();
        void Dispose();
    }
}
