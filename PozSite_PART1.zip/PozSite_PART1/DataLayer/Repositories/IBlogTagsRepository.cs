﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface IBlogTagsRepository
    {
        List<Blog_Tags> GetAllBlogTags();
        List<Blog_Tags> GetNameBlogTags(string filter = "");
        Blog_Tags GetBlogTagById(int blogTagId);
        bool InsertBlogTag(Blog_Tags blogTag);
        bool UpdateBlogTag(Blog_Tags blogTag);
        bool DeleteBlogTag(Blog_Tags blogTag);
        bool DeleteBlogTag(int blogTagId);
        void Save();
    }
}
