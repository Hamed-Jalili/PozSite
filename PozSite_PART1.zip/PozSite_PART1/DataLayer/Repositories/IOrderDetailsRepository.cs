﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface IOrderDetailsRepository
    {
        List<OrderDetails> GetAllOrderDetails();
        OrderDetails GetOrderDetailById(int orderDetailId);
        List<OrderDetails> GetOrderDetailByOrderId(int orderlId);
        bool InsertOrderDetail(OrderDetails orderDetail);
        bool UpdateOrderDetail(OrderDetails orderDetail);
        bool DeleteOrderDetail(OrderDetails orderDetail);
        bool DeleteOrderDetail(int orderDetailId);
        void Save();
        void Dispose();
    }
}
