﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface IOnlineOrderRepository
    {
        List<OnlineOrder> GetAllOnlineOrders();
        OnlineOrder GetOnlineOrderById(int onlineOrderId);
        bool InsertOnlineOrder(OnlineOrder onlineOrder);
        bool UpdateOnlineOrder(OnlineOrder onlineOrder);
        bool DeleteOnlineOrder(OnlineOrder onlineOrder);
        bool DeleteOnlineOrder(int onlineOrderId);
        void Save();
        void Dispose();
    }
}
