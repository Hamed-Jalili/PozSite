﻿using System;
using System.Collections.Generic;

namespace DataLayer.Repositories
{
    
    public interface IConfigRepository: IDisposable
    {
        List<MetaDataClasses.Config> SelectAllConfig();
        MetaDataClasses.Config SelectConfigById(int configId);
        bool InsertConfig(MetaDataClasses.Config config);
        bool UpdateConfig(MetaDataClasses.Config config);
        bool DeleteConfig(MetaDataClasses.Config config);
        bool DeleteConfig(int configId);
        MetaDataClasses.Config SelectConfigByAbout(int configId);
        MetaDataClasses.Config SelectConfigByContact(int configId);
        MetaDataClasses.Config SelectConfigByPolicies(int configId);
        void Save();

    }
}
