﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface IProductGroupsRepository
    {
        List<Product_Groups> GetAllProductGroups();
        Product_Groups GetProductGroupsById(int productGroupsId);
        bool GetProductGroupsByParentId(int productParentId);
        bool GetProductGroupsBySelectGroup(int productSelectedGroupsId);
        bool InsertProductGroups(Product_Groups productGroups);
        bool UpdateProductGroups(Product_Groups productGroups);
        bool DeleteProductGroups(Product_Groups productGroups);
        bool DeleteProductGroups(int productGroupsId);
        void Save();
    }
}
