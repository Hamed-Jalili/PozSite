﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface IBlogGroupsRepository
    {
        List<Blog_Groups> GetAllBlogGroups();
        Blog_Groups GetBlogGroupById(int blogGroupId);
        bool InsertBlogGroup(Blog_Groups blogGroup);
        bool UpdateBlogGroup(Blog_Groups blogGroup);
        bool DeleteBlogGroup(Blog_Groups blogGroupId);
        bool DeleteBlogGroup(int blogGroupId);
        void Save();
        void Dispose();
    }
}
