﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface IProductGalleriesRepository
    {
        List<Product_Galleries> GetAllProductGalleries();
        Product_Galleries GetProductGallerieById(int productGallerieId);
        List<Product_Galleries> GetProductGallerieByProductId(int productGallerieProductId);
        bool InsertProductGallerie(Product_Galleries productGallerie);
        bool UpdateProductGallerie(Product_Galleries productGallerie);
        bool DeleteProductGallerie(Product_Galleries productGallerie);
        bool DeleteProductGallerie(int productGallerieId);
        void Save();
    }
}
