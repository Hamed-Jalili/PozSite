﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface IBlogRepository
    {
        List<Blog> GetAllBlogs();
        List<Blog> GetNameBlogs(string filter = "");
        List<Blog> GetBlogsByGroupId(int groupId);
        List<Blog> GetBlogsByIsSuggested();
        Blog GetblogById(int blogId);
        bool InsertBlog(Blog blog);
        bool UpdateBlog(Blog blog);
        bool DeleteBlog(Blog blog);
        bool DeleteBlog(int blogId);
        void Save();
    }
}
