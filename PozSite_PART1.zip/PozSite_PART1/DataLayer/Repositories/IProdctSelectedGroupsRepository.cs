﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface IProdctSelectedGroupsRepository
    {
        List<Prodct_Selected_Groups> GetAllProdctSelectedGroups();
        Prodct_Selected_Groups GetProdctSelectedGroupsById(int prodctSelectedGroupId);
        bool InsertProdctSelectedGroup(Prodct_Selected_Groups prodctSelectedGroup);
        bool UpdateProdctSelectedGroup(Prodct_Selected_Groups prodctSelectedGroup);
        bool DeleteProdctSelectedGroup(Prodct_Selected_Groups prodctSelectedGroup);
        bool DeleteProdctSelectedGroup(int prodctSelectedGroupId);
        void Save();
    }
}
