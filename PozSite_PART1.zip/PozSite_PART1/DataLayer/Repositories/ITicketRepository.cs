﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface ITicketRepository
    {
        List<Ticket> GetAllTicket();
        List<Ticket> GetAllTicketNotAsnwer();
        List<Ticket> GetTicketByUser(int userId);
        Ticket GetTicketById(int ticketId);
        bool InsertTicket(Ticket ticket);
        bool UpdateTicket(Ticket ticket);
        bool DeleteTicket(Ticket ticket);
        bool DeleteTicket(int ticketId);
        void Save();
        void Dispose();

    }
}
