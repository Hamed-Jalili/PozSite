﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface IUsersRepository
    {
        List<Users> GetAllUsers();
        Users GetUserById(int userId);
        Users GetUserByUserName(string userName);
        bool InsertUser(Users user);
        bool UpdateUser(Users user);
        bool DeleteUser(Users user);
        bool DeleteUser(int userId);
        void Save();
        void Dispose();

    }
}
