﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface IBlogCommentsRepository
    {
        List<Blog_Comments> GetAllBlogComments();
        List<Blog_Comments> GetNameBlogComments(string filter = "");
        Blog_Comments GetBlogCommentById(int blogCommentId);
        bool InsertBlogComment(Blog_Comments blogComment);
        bool UpdateBlogComment(Blog_Comments blogComment);
        bool DeleteBlogComment(Blog_Comments blogComment);
        bool DeleteBlogComment(int blogCommentId);
        void Save();
    }
}
