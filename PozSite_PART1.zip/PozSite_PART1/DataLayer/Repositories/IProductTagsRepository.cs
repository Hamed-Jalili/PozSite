﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface IProductTagsRepository
    {
        List<Product_Tags> GetAllProductTags();
        Product_Tags GetProductTagsById(int productTagsId);
        bool InsertProductTags(Product_Tags productTags);
        bool UpdateProductTags(Product_Tags productTags);
        bool DeleteProductTags(Product_Tags productTags);
        bool DeleteProductTags(int productId);
        void Save();
    }
}
