﻿namespace DataLayer.Repositories
{
    public interface ISiteVisitRepository
    {
    }
}
