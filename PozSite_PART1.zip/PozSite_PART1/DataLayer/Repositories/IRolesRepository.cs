﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface IRolesRepository
    {
        List<Roles> GetAllRoles();
        Roles GetRoleById(int roleId);
        bool InserRole(Roles role);
        bool UpdateRole(Roles role);
        bool DeleteRole(Roles role);
        bool DeleteRole(int roleId);
        void Save();
        void Dispose();

    }
}
