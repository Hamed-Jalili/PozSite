﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface ISliderRepository
    {
        List<Slider> GetAllSliders();
        Slider GetSliderById(int sliderId);
        bool InsertSlider(Slider slider);
        bool UpdateSlider(Slider slider);
        bool DeleteSlider(Slider slider);
        bool DeleteSlider(int sliderId);
        void Save();
        void Dispose();
    }
}
