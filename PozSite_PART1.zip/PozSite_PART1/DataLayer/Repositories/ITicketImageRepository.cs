﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface ITicketImageRepository
    {
        List<Ticket_Image> GetAllTicketImage();
        Ticket_Image GetTicketImageById(int ticketImageId);
        Ticket_Image GetTicketImageByTicketId(int ticketImageId);
        bool InsertTicketImage(Ticket_Image ticketImage);
        bool UpdateTicketImage(Ticket_Image ticketImage);
        bool DeleteTicketImage(Ticket_Image ticketImage);
        bool DeleteTicketImage(int ticketImageId);
        void Save();
        void Dispose();

    }
}
