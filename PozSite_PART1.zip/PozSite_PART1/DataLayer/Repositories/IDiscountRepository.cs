﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface IDiscountRepository
    {
        List<Discount> GetAllDiscounts();
        List<Discount> GetNameDiscounts(string filter = "");
        Discount GetDiscountById(int discountId);
        bool InsertDiscount(Discount discount);
        bool UpdateDiscount(Discount discount);
        bool DeleteDiscount(Discount discount);
        bool DeleteDiscount(int discountId);
        void Save();
        void Dispose();
    }
}
