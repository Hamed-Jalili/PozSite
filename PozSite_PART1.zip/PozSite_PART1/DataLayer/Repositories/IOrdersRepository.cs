﻿using System.Collections.Generic;

namespace DataLayer.Repositories
{
    public interface IOrdersRepository
    {
        List<Orders> GetAllOrders();
        Orders GetOrdersById(int ordersId);
        List<Orders> GetOrdersByUserId(int orderUserId);
        bool InsertOrder(Orders order);
        bool UpdateOrder(Orders order);
        bool DeleteOrder(Orders order);
        bool DeleteOrder(int orderId);
        void Save();
        void Dispose();
    }
}
