﻿using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class ProductTagsRepository : IProductTagsRepository
    {
        private asamedc1_bazarjeEntities db;
        public ProductTagsRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }

        public List<Product_Tags> GetAllProductTags()
        {
            return db.Product_Tags.ToList();
        }

        public Product_Tags GetProductTagsById(int productTagsId)
        {
            return db.Product_Tags.Find(productTagsId);
        }

        public bool InsertProductTags(Product_Tags productTags)
        {
            try
            {
                db.Product_Tags.Add(productTags);
                Save();
                return true;
            }
            catch 
            {
                return false;
            }
        }

       

        public bool UpdateProductTags(Product_Tags productTags)
        {
            try
            {
                var local = db.Set<Product_Tags>()
              .Local
              .FirstOrDefault(f => f.TagID == productTags.TagID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(productTags).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool DeleteProductTags(Product_Tags productTags)
        {
            try
            {
                db.Entry(productTags).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteProductTags(int productId)
        {
            try
            {
                var product = GetProductTagsById(productId);
                DeleteProductTags(product);
                return true;
            }
            catch 
            {
                return false;
            }
        }
        public void Save()
        {
            db.SaveChanges();
        }
        public void Dispose()
        {
            db.Dispose();
        }
    }
}
