﻿using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class DiscountRepository : IDiscountRepository
    {
        asamedc1_bazarjeEntities db;
        public DiscountRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }
        public List<Discount> GetAllDiscounts()
        {
            return db.Discount.ToList();
        }

        public Discount GetDiscountById(int discountId)
        {
            return db.Discount.Find(discountId);
        }

        public List<Discount> GetNameDiscounts(string filter = "")
        {
            return db.Discount.Where(i => i.Name == filter).ToList();
        }

        public bool InsertDiscount(Discount discount)
        {
            try
            {
                db.Discount.Add(discount);
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool UpdateDiscount(Discount discount)
        {
            try
            {
                var local = db.Set<Discount>()
            .Local
            .FirstOrDefault(f => f.DiscountID == discount.DiscountID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(discount).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool DeleteDiscount(Discount discount)
        {
            try
            {
                db.Entry(discount).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteDiscount(int discountId)
        {
            try
            {
                DeleteDiscount(GetDiscountById(discountId));
                return true;
            }
            catch
            {
                return false;
            }
        }
        public void Save()
        {
            db.SaveChanges();
        }
        public void Dispose()
        {
            db.Dispose();
        }

    }
}
