﻿using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class UsersRepository : IUsersRepository
    {
        private asamedc1_bazarjeEntities db;
        public UsersRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }
        public List<Users> GetAllUsers()
        {
            return db.Users.ToList();
        }

        public Users GetUserById(int userId)
        {
            return db.Users.Find(userId);
        }

        public bool InsertUser(Users user)
        {
            try
            {
                db.Users.Add(user);
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool UpdateUser(Users user)
        {
            try
            {
                var local = db.Set<Users>()
              .Local
              .FirstOrDefault(f => f.UserID == user.UserID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(user).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool DeleteUser(Users user)
        {
            try
            {
                db.Entry(user).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool DeleteUser(int userId)
        {
            try
            {
                DeleteUser(GetUserById(userId));
                return true;
            }
            catch
            {
                return false;
            }
        }
        public void Save()
        {
            db.SaveChanges();
        }
        public void Dispose()
        {
            db.Dispose();
        }

        public Users GetUserByUserName(string userName)
        {
            return db.Users.SingleOrDefault(i => i.UserName == userName);
        }
    }
}
