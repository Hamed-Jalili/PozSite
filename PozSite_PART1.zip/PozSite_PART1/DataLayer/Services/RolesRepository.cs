﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class RolesRepository : IRolesRepository
    {
        private asamedc1_bazarjeEntities db;
        public RolesRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }
        public List<Roles> GetAllRoles()
        {
            return db.Roles.ToList();
        }

        public Roles GetRoleById(int roleId)
        {
            return db.Roles.Find(roleId);
        }

        public bool InserRole(Roles role)
        {
            try
            {
                db.Roles.Add(role);
                Save();
                return true;
            }
            catch 
            {
                return false;
            }
        }
        public bool UpdateRole(Roles role)
        {
            try
            {
                var local = db.Set<Roles>().Local.FirstOrDefault(f => f.RoleID == role.RoleID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(role).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool DeleteRole(Roles role)
        {
            try
            {
                db.Entry(role).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteRole(int roleId)
        {
            try
            {
                DeleteRole(GetRoleById(roleId));
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public void Save()
        {
            db.SaveChanges();
        }
        public void Dispose()
        {
            db.Dispose();
        }

    }
}
