﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class BlogGroupsRepository : IBlogGroupsRepository
    {
        private asamedc1_bazarjeEntities db;
        public BlogGroupsRepository(asamedc1_bazarjeEntities context)
        {
            db = context;

        }
      
        public List<Blog_Groups> GetAllBlogGroups()
        {
            return db.Blog_Groups.ToList();
        }

        public Blog_Groups GetBlogGroupById(int blogGroupId)
        {
            return db.Blog_Groups.Find(blogGroupId);
        }

        public bool InsertBlogGroup(Blog_Groups blogGroup)
        {
            try
            {
                db.Blog_Groups.Add(blogGroup);
                Save();
                return true;
            }
            catch 
            {
                return false;
            }
        }
        public bool UpdateBlogGroup(Blog_Groups blogGroup)
        {
            try
            {
                var local = db.Set<Blog_Groups>()
                    .Local
                    .FirstOrDefault(f => f.GroupID == blogGroup.GroupID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(blogGroup).State = EntityState.Modified;
                Save();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteBlogGroup(Blog_Groups blogGroupId)
        {
            try
            {
                db.Entry(blogGroupId).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteBlogGroup(int blogGroupId)
        {
            try
            {
                var customer = GetBlogGroupById(blogGroupId);
                DeleteBlogGroup(customer);
                return true;
            }
            catch 
            {
                return false;
            }
        }
        public void Save()
        {
            db.SaveChanges();
        }

        public void Dispose()
        {
            db.Dispose();
        }
    }
}
