﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class AdRepository : IAdRepository
    {
        private asamedc1_bazarjeEntities db;

        public AdRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }
        public List<Ad> GetAllAds()
        {
            return db.Ad.ToList();
        }
        public Ad GetAdById(int adId)
        {
            return db.Ad.Find(adId);
        }
        public List<Ad> GetNameAds(string filter = "")
        {
            throw new NotImplementedException();
        }
        public bool InsertAd(Ad ad)
        {
            try
            {
                db.Ad.Add(ad);
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool UpdateAd(Ad ad)
        {
            try
            {
                var local = db.Set<Ad>()
                    .Local
                    .FirstOrDefault(f => f.AdID == ad.AdID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(ad).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool DeleteAd(Ad ad)
        {
            try
            {
                db.Entry(ad).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool DeleteAd(int adId)
        {
            try
            {
                var customer = GetAdById(adId);
                DeleteAd(customer);
                return true;
            }
            catch
            {
                return false;
            }
        }
        public void Save()
        {
            db.SaveChanges();
        }
        public void Dispose()
        {
            db.Dispose();
        }

        public Ad GetAdsByRandoms()
        {
            List<Ad> addd = db.Ad.OrderBy(r => Guid.NewGuid()).ToList();
            if (addd.Count != 0)
            {
                return addd[0];
            }
            else
            {
                Ad ad = null;
                return ad;
            }
        }
    }
}
