﻿using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class ProdctSelectedGroupsRepository : IProdctSelectedGroupsRepository
    {
        private asamedc1_bazarjeEntities db;
        public ProdctSelectedGroupsRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }

        public List<Prodct_Selected_Groups> GetAllProdctSelectedGroups()
        {
            return db.Prodct_Selected_Groups.ToList();
        }

        public Prodct_Selected_Groups GetProdctSelectedGroupsById(int prodctSelectedGroupId)
        {
            return db.Prodct_Selected_Groups.Find(prodctSelectedGroupId);
        }

        public bool InsertProdctSelectedGroup(Prodct_Selected_Groups prodctSelectedGroup)
        {
            try
            {
                db.Prodct_Selected_Groups.Add(prodctSelectedGroup);
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool UpdateProdctSelectedGroup(Prodct_Selected_Groups prodctSelectedGroup)
        {
            try
            {
                var local = db.Set<Prodct_Selected_Groups>()
              .Local
              .FirstOrDefault(f => f.PG_ID == prodctSelectedGroup.PG_ID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(prodctSelectedGroup).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool DeleteProdctSelectedGroup(Prodct_Selected_Groups prodctSelectedGroup)
        {
            try
            {
                db.Entry(prodctSelectedGroup).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteProdctSelectedGroup(int prodctSelectedGroupId)
        {
            try
            {
                var product = GetProdctSelectedGroupsById(prodctSelectedGroupId);
                DeleteProdctSelectedGroup(product);
                return true;
            }
            catch
            {
                return false;
            }
        }
        public void Save()
        {
            db.SaveChanges();
        }
       

    }
}
