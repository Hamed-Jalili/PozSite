﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class OnlineOrderRepository : IOnlineOrderRepository
    {
        private asamedc1_bazarjeEntities db;
        public OnlineOrderRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }
        public List<OnlineOrder> GetAllOnlineOrders()
        {
            return db.OnlineOrder.ToList();
        }

        public OnlineOrder GetOnlineOrderById(int onlineOrderId)
        {
            return db.OnlineOrder.Find(onlineOrderId);
        }

        public bool InsertOnlineOrder(OnlineOrder onlineOrder)
        {
            try
            {
                db.OnlineOrder.Add(onlineOrder);
                Save();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }



        public bool UpdateOnlineOrder(OnlineOrder onlineOrder)
        {
            try
            {
                var local = db.Set<OnlineOrder>()
                     .Local
                     .FirstOrDefault(f => f.OrderID == onlineOrder.OrderID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(onlineOrder).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool DeleteOnlineOrder(OnlineOrder onlineOrder)
        {
            try
            {
                db.Entry(onlineOrder).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteOnlineOrder(int onlineOrderId)
        {
            try
            {
                DeleteOnlineOrder(GetOnlineOrderById(onlineOrderId));
                return true;
            }
            catch
            {
                return false;
            }
        }
        public void Save()
        {
            db.SaveChanges();
        }

        public void Dispose()
        {
            db.Dispose();
        }
    }
}
