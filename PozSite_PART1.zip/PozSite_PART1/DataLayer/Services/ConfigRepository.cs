﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class ConfigRepository : IConfigRepository
    {
        asamedc1_bazarjeEntities db;

        public ConfigRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }
        public bool DeleteConfig(MetaDataClasses.Config config)
        {
            try
            {
                db.Entry(config).State = EntityState.Deleted;
                return true;
            }
            catch 
            {
                return false;
            }
        }

        public bool DeleteConfig(int configId)
        {
            try
            {
                var config = SelectConfigById(configId);
                DeleteConfig(config);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public void Dispose()
        {
            db.Dispose();
        }

        public bool InsertConfig(MetaDataClasses.Config config)
        {
            try
            {
                db.Config.Add(config);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public void Save()
        {
            db.SaveChanges();
        }

        public List<MetaDataClasses.Config> SelectAllConfig()
        {
           return db.Config.ToList();
        }

        public MetaDataClasses.Config SelectConfigByAbout(int configId)
        {
            throw new NotImplementedException();
        }

        public MetaDataClasses.Config SelectConfigByContact(int configId)
        {
            throw new NotImplementedException();
        }
        public MetaDataClasses.Config SelectConfigById(int configId)
        {
            return db.Config.Find(configId);
        }
        public MetaDataClasses.Config SelectConfigByPolicies(int configId)
        {
            throw new NotImplementedException();
        }

        public bool UpdateConfig(MetaDataClasses.Config config)
        {
            try
            {
                var local = db.Set<MetaDataClasses.Config>()
                     .Local
                     .FirstOrDefault(f => f.id == config.id);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(config).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
