﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace DataLayer.Services
{
    public class FeaturesRepository : IFeaturesRepository
    {
        private asamedc1_bazarjeEntities db;
        public FeaturesRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }
        public List<Features> GetAllFeatures()
        {
            return db.Features.ToList();
        }

        public Features GetFeaturesById(int featureId)
        {
            return db.Features.Find(featureId);
        }

        public bool InsertFeatures(Features feature)
        {
            try
            {
                db.Features.Add(feature);
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool UpdateFeatures(Features feature)
        {
            try
            {
                var local = db.Set<Features>()
              .Local
              .FirstOrDefault(f => f.FeatureID == feature.FeatureID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(feature).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool DeleteFeatures(Features feature)
        {
            try
            {
                db.Entry(feature).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteFeatures(int featureId)
        {
            try
            {
                var featur = GetFeaturesById(featureId);
                DeleteFeatures(featur);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public void Save()
        {
            db.SaveChanges();
        }
        public void Dispose()
        {
            db.Dispose();
        }

    }
}
