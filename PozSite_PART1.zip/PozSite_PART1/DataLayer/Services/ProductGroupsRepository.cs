﻿using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class ProductGroupsRepository : IProductGroupsRepository
    {
        private asamedc1_bazarjeEntities db;
        public ProductGroupsRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }
        public bool DeleteProductGroups(Product_Groups productGroups)
        {
            try
            {
                db.Entry(productGroups).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteProductGroups(int productGroupsId)
        {
            try
            {
                var product = GetProductGroupsById(productGroupsId);
                DeleteProductGroups(product);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public List<Product_Groups> GetAllProductGroups()
        {
            return db.Product_Groups.ToList();
        }

        public Product_Groups GetProductGroupsById(int productGroupsId)
        {
            return db.Product_Groups.Find(productGroupsId);
        }

        public bool InsertProductGroups(Product_Groups productGroups)
        {
            try
            {
                db.Product_Groups.Add(productGroups);
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public void Save()
        {
            db.SaveChanges();
        }

        public bool UpdateProductGroups(Product_Groups productGroups)
        {
            try
            {
                var local = db.Set<Product_Groups>()
            .Local
            .FirstOrDefault(f => f.GroupID == productGroups.GroupID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(productGroups).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public void Dispose()
        {
            db.Dispose();
        }

        public bool GetProductGroupsByParentId(int productParentId)
        {
            return db.Product_Groups.Any(i => i.ParentID == productParentId);
        }

        public bool GetProductGroupsBySelectGroup(int productSelectedGroupsId)
        {
            return db.Prodct_Selected_Groups.Any(i => i.GroupID == productSelectedGroupsId);
        }
    }

}
