﻿using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class OrderDetailsRepository : IOrderDetailsRepository
    {
        private asamedc1_bazarjeEntities db;
        public OrderDetailsRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }

        public List<OrderDetails> GetAllOrderDetails()
        {
            return db.OrderDetails.ToList();
        }

        public OrderDetails GetOrderDetailById(int orderDetailId)
        {
            return db.OrderDetails.Find(orderDetailId);
        }

        public bool InsertOrderDetail(OrderDetails orderDetail)
        {
            try
            {
                db.OrderDetails.Add(orderDetail);
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool UpdateOrderDetail(OrderDetails orderDetail)
        {
            try
            {
                var local = db.Set<OrderDetails>().Local.FirstOrDefault(f => f.DetailID == orderDetail.DetailID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(orderDetail).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool DeleteOrderDetail(OrderDetails orderDetail)
        {
            try
            {
                db.Entry(orderDetail).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteOrderDetail(int orderDetailId)
        {
            try
            {
                DeleteOrderDetail(GetOrderDetailById(orderDetailId));
                return true;
            }
            catch
            {
                return false;
            }
        }
        public void Save()
        {
            db.SaveChanges();
        }

        public void Dispose()
        {
            db.SaveChanges();
        }

        public List<OrderDetails> GetOrderDetailByOrderId(int orderlId)
        {
            List<OrderDetails> details = db.OrderDetails.Where(i => i.OrderID == orderlId).ToList();
            return details;
        }
    }
}
