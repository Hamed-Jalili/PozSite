﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class ProductsRepository : IProductsRepository
    {
        private asamedc1_bazarjeEntities db;

        public ProductsRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }

        

        public List<Products> GetAllProducts()
        {
            return db.Products.ToList();
        }

        public IEnumerable<Products> GetCusstomersByFilter(string parameter)
        {
            return db.Products.Where(c =>
                c.Title.Contains(parameter) || c.Text.Contains(parameter) || c.ShortDescription.Contains(parameter)).ToList();
        }
        public List<Products> GetNameProducts(string filter = "")
        {
            throw new NotImplementedException();
        }

        public Products GetProductById(int productId)
        {
            return db.Products.Find(productId);

        }

        public int GetProductIdByName(string name)
        {
            return db.Products.First(c => c.Title == name).ProductID;
        }

        public string GetProductNameById(int productId)
        {
            throw new NotImplementedException();
        }

        public bool InsertProduct(Products product)
        {
            try
            {
                db.Products.Add(product);
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool UpdateProduct(Products product)
        {
            try
            {
                var local = db.Set<Products>()
               .Local
               .FirstOrDefault(f => f.ProductID == product.ProductID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(product).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public List<Products> GetLastProducts(int take)
        {
            return db.Products.OrderByDescending(p => p.CreateDate).Take(take).ToList(); ;
        }
        public bool DeleteProduct(Products product)
        {
            try
            {
                db.Entry(product).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteProduct(int productId)
        {
            try
            {
                var customer = GetProductById(productId);
                DeleteProduct(customer);
                return true;
            }
            catch
            {
                return false;
            }
        }
        public void Save()
        {
            db.SaveChanges();
        }
        public void Dispose()
        {
            db.Dispose();
        }

       
    }
}
