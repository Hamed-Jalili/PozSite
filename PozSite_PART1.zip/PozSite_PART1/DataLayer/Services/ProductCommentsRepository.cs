﻿using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class ProductCommentsRepository : IProductCommentsRepository
    {
        asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        public ProductCommentsRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }
        public List<Product_Comments> GetAllProductComments()
        {
            return db.Product_Comments.ToList();
        }

        public Product_Comments GetProductCommentById(int productCommentId)
        {
            return db.Product_Comments.Find(productCommentId);
        }

        public bool InsertProductComment(Product_Comments productComment)
        {
            try
            {
                db.Product_Comments.Add(productComment);
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool UpdateProductComment(Product_Comments productComment)
        {
            try
            {
                var local = db.Set<Product_Comments>()
                   .Local
                   .FirstOrDefault(f => f.CommentID == productComment.CommentID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(productComment).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool DeleteProductComment(Product_Comments productComment)
        {
            try
            {
                db.Entry(productComment).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteProductComment(int productCommentId)
        {
            try
            {
                DeleteProductComment(GetProductCommentById(productCommentId));
                return true;
            }
            catch
            {
                return false;
            }
        }
        public void Save()
        {
            db.SaveChanges();
        }

        public void Dispose()
        {
            db.SaveChanges();
        }
    }
}
