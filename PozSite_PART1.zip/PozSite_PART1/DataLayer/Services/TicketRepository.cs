﻿using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class TicketRepository : ITicketRepository
    {
        private asamedc1_bazarjeEntities db;
        public TicketRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }
        public List<Ticket> GetAllTicket()
        {
            return db.Ticket.ToList();
        }

        public Ticket GetTicketById(int ticketId)
        {
            return db.Ticket.Find(ticketId);
        }

        public bool InsertTicket(Ticket ticket)
        {
            try
            {
                db.Ticket.Add(ticket);
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool UpdateTicket(Ticket ticket)
        {
            try
            {
                var local = db.Set<Ticket>()
             .Local
             .FirstOrDefault(f => f.TicketID == ticket.TicketID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(ticket).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return true;
            }
        }
        public bool DeleteTicket(Ticket ticket)
        {
            try
            {
                db.Entry(ticket).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteTicket(int ticketId)
        {
            try
            {
                DeleteTicket(GetTicketById(ticketId));
                return true;
            }
            catch
            {
                return false;
            }
        }
        public void Save()
        {
            db.SaveChanges();
        }
        public void Dispose()
        {
            db.SaveChanges();
        }

        public List<Ticket> GetAllTicketNotAsnwer()
        {
            return db.Ticket.Where(i=>i.IsAnswered==false && i.IsAdmin==false).ToList();
        }

        public List<Ticket> GetTicketByUser(int userId)
        {
            return db.Ticket.Where(i => i.UserID == userId).ToList();
        }
    }
}
