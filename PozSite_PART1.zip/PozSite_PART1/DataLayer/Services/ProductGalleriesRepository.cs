﻿using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class ProductGalleriesRepository : IProductGalleriesRepository
    {
        private asamedc1_bazarjeEntities db;
        public ProductGalleriesRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }
        public List<Product_Galleries> GetAllProductGalleries()
        {
           return  db.Product_Galleries.ToList();
        }

        public Product_Galleries GetProductGallerieById(int productGallerieId)
        {
            return db.Product_Galleries.Find(productGallerieId);
        }

        public bool InsertProductGallerie(Product_Galleries productGallerie)
        {
            try
            {
                db.Product_Galleries.Add(productGallerie);
                Save();
                return true;
            }
            catch 
            {
                return false;
            }
        }
        public bool UpdateProductGallerie(Product_Galleries productGallerie)
        {
            try
            {
                var local = db.Set<Product_Galleries>()
                    .Local
                    .FirstOrDefault(f => f.GalleryID == productGallerie.GalleryID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(productGallerie).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool DeleteProductGallerie(Product_Galleries productGallerie)
        {
            try
            {
                db.Entry(productGallerie).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteProductGallerie(int productGallerieId)
        {
            try
            {
                var product = GetProductGallerieById(productGallerieId);
                DeleteProductGallerie(product);
                return true;
            }
            catch
            {
                return false;
            }
        }
        public void Save()
        {
            db.SaveChanges();
        }
        public void Dispose()
        {
            db.Dispose();
        }

        public List<Product_Galleries> GetProductGallerieByProductId(int productGallerieProductId)
        {
            return db.Product_Galleries.Where(i=>i.ProductID== productGallerieProductId).ToList();
        }
    }
}
