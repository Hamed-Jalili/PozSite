﻿using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class OrdersRepository : IOrdersRepository
    {
        private asamedc1_bazarjeEntities db;
        public OrdersRepository(asamedc1_bazarjeEntities context)
        {
            db = new asamedc1_bazarjeEntities();
        }
        

        public List<Orders> GetAllOrders()
        {
            return db.Orders.ToList();
        }

        public Orders GetOrdersById(int ordersId)
        {
             return db.Orders.Find(ordersId);
        }

        public bool InsertOrder(Orders order)
        {
            try
            {
                db.Orders.Add(order);
                Save();
                return true;
            }
            catch 
            {
                return false;
            }
        }
        public bool UpdateOrder(Orders order)
        {
            try
            {
                var local = db.Set<Orders>().Local.FirstOrDefault(f => f.OrderID == order.OrderID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(order).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool DeleteOrder(Orders order)
        {
            try
            {
                db.Entry(order).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteOrder(int orderId)
        {
            try
            {
                DeleteOrder(GetOrdersById(orderId));
                return true;
            }
            catch
            {
                return false;
            }      
        }
        public void Save()
        {
            db.SaveChanges();
        }
        public void Dispose()
        {
            db.Dispose();
        }

        List<Orders> IOrdersRepository.GetOrdersByUserId(int orderUserId)
        {
            return db.Orders.Where(i => i.UserID == orderUserId).ToList();
        }
    }
}
