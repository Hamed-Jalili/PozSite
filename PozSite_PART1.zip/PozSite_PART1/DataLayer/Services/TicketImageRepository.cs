﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class TicketImageRepository : ITicketImageRepository
    {
        private asamedc1_bazarjeEntities db;

        public TicketImageRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }
        public List<Ticket_Image> GetAllTicketImage()
        {
            return db.Ticket_Image.ToList();
        }

        public Ticket_Image GetTicketImageById(int ticketImageId)
        {
            return db.Ticket_Image.Find(ticketImageId);
        }

        public bool InsertTicketImage(Ticket_Image ticketImage)
        {
            try
            {
                db.Ticket_Image.Add(ticketImage);
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool UpdateTicketImage(Ticket_Image ticketImage)
        {
            try
            {
                var local = db.Set<Ticket_Image>().Local.FirstOrDefault(f => f.ImageID == ticketImage.ImageID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(ticketImage).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteTicketImage(Ticket_Image ticketImage)
        {
            try
            {
                db.Entry(ticketImage).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteTicketImage(int ticketImageId)
        {
            try
            {
                DeleteTicketImage(GetTicketImageById(ticketImageId));
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public void Save()
        {
            db.SaveChanges();
        }
        public void Dispose()
        {
            db.Dispose();
        }

        public Ticket_Image GetTicketImageByTicketId(int ticketImageId)
        {
            return db.Ticket_Image.SingleOrDefault(i => i.TicketID == ticketImageId);
        }
    }
}
