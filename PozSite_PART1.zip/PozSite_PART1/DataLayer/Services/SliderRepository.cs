﻿using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class SliderRepository : ISliderRepository
    {
        private asamedc1_bazarjeEntities db;
        public SliderRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }
        public List<Slider> GetAllSliders()
        {
            return db.Slider.ToList();
        }

        public Slider GetSliderById(int sliderId)
        {
            return db.Slider.Find(sliderId);
        }

        public bool InsertSlider(Slider slider)
        {
            try
            {
                db.Slider.Add(slider);
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool UpdateSlider(Slider slider)
        {
            try
            {
                var local = db.Set<Slider>()
              .Local
              .FirstOrDefault(f => f.SlideID == slider.SlideID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(slider).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool DeleteSlider(Slider slider)
        {
            try
            {
                db.Entry(slider).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteSlider(int sliderId)
        {
            try
            {
                DeleteSlider(GetSliderById(sliderId));
                return true;
            }
            catch
            {
                return false;
            }
        }
        public void Save()
        {
            db.SaveChanges();
        }
        public void Dispose()
        {
            db.Dispose();
        }
        
    }
}
