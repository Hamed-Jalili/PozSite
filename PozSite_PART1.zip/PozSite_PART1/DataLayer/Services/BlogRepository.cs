﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    public class BlogRepository: IBlogRepository
    {
        private asamedc1_bazarjeEntities db;

        public BlogRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }
       
        public void Save()
        {
            db.SaveChanges();
        }
        public void Dispose()
        {
            db.Dispose();
        }
        public List<Blog> GetAllBlogs()
        {
            return db.Blog.ToList();
        }
        public List<Blog> GetNameBlogs(string filter = "")
        {
            throw new NotImplementedException();
        }

        public Blog GetblogById(int blogId)
        {
            return db.Blog.Find(blogId);
        }

        public bool InsertBlog(Blog blog)
        {
            try
            {
                db.Blog.Add(blog);
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool UpdateBlog(Blog blog)
        {
            try
            {
                var local = db.Set<Blog>()
                    .Local
                    .FirstOrDefault(f => f.BlogID == blog.BlogID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(blog).State = EntityState.Modified;
                Save();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool DeleteBlog(Blog blog)
        {
            try
            {
                db.Entry(blog).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool DeleteBlog(int blogId)
        {
            try
            {
                var customer = GetblogById(blogId);
                DeleteBlog(customer);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public List<Blog> GetBlogsByGroupId(int groupId)
        {
            return db.Blog.Where(i => i.GroupeId == groupId).ToList();
        }

        public List<Blog> GetBlogsByIsSuggested()
        {
            return db.Blog.Where(i => i.IsSuggested).ToList();
        }
    }
}
