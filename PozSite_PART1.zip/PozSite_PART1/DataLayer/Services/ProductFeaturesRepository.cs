﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using DataLayer.Repositories;

namespace DataLayer.Services
{
    public class ProductFeaturesRepository : IProductFeaturesRepository
    {
        private asamedc1_bazarjeEntities db;
        public ProductFeaturesRepository(asamedc1_bazarjeEntities context)
        {
            db = context;
        }


        public List<Product_Features> GetAllProductFeatures()
        {
            return db.Product_Features.ToList();
        }

        public Product_Features GetProductFeatureById(int productFeatureId)
        {
            return db.Product_Features.Find(productFeatureId);
        }

        public bool InsertProductFeature(Product_Features productFeature)
        {
            try
            {
                db.Product_Features.Add(productFeature);
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool DeleteProductFeature(Product_Features productFeature)
        {
            try
            {
                db.Entry(productFeature).State = EntityState.Deleted;
                Save();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool DeleteProductFeature(int productFeatureId)
        {
            try
            {
                var product = GetProductFeatureById(productFeatureId);
                DeleteProductFeature(product);
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool UpdateProductFeature(Product_Features productFeature)
        {

            try
            {
                var local = db.Set<Product_Features>()
            .Local
            .FirstOrDefault(f => f.PF_ID == productFeature.PF_ID);
                if (local != null)
                {
                    db.Entry(local).State = EntityState.Detached;
                }
                db.Entry(productFeature).State = EntityState.Modified;
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public void Save()
        {
            db.SaveChanges();
        }
        public void Dispose()
        {
            db.Dispose();
        }
    }
}
