﻿namespace DataLayer.MetaDataClasses
{
    internal class OrderDetailsMetaData
    {
    }
}