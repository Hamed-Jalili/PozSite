﻿namespace DataLayer.MetaDataClasses
{
    internal class Product_TagsMetaData
    {
    }
}