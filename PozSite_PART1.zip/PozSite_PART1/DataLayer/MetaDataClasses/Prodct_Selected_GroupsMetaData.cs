﻿namespace DataLayer.MetaDataClasses
{
    internal class Prodct_Selected_GroupsMetaData
    {
    }
}