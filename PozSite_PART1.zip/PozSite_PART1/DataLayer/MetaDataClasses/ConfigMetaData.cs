﻿using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace DataLayer.MetaDataClasses
{
    public class ConfigMetaData
    {
        public int id { get; set; }
        [Display(Name ="درباره ما")]
        [DataType(DataType.MultilineText)]
        [AllowHtml]
        public string AboutUs { get; set; }
        [Display(Name = "تماس با ما")]
        [DataType(DataType.MultilineText)]
        [AllowHtml]
        public string ContactUs { get; set; }
        [Display(Name = "قوانین")]
        [DataType(DataType.MultilineText)]
        [AllowHtml]
        public string Policies { get; set; }
    }
    [MetadataType(typeof(ConfigMetaData))]
    public partial class Config
    {
        
    }
}
