﻿namespace DataLayer
{
    internal class SiteVisitMetaData
    {
    }
}