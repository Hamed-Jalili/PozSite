﻿namespace DataLayer
{
    internal class OrdersMetaData
    {
    }
}