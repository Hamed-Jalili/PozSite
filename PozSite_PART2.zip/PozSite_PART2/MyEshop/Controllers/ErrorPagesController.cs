﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MyEshop.Controllers
{
    public class ErrorPagesController : Controller
    {
        // GET: ErrorPages
        public ViewResult Index()
        {
            return View("Error");
        }
        [HandleError]
        public ViewResult NotFound()
        {
            Response.StatusCode = 404;  //you may want to set this to 200
            return View("NotFound");
        }

        [Route("404")]
        public ActionResult NotFoundPage()
        {
            return View();
        }
    }
}