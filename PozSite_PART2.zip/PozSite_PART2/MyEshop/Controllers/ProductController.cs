﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using DataLayer.Repositories;
using DataLayer.Services;
using DataLayer.ViewModels;
using MyEshop.MoreLinq;

namespace MyEshop.Controllers
{
    public class ProductController : Controller
    {
        asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private IProductsRepository _products;
        private DataLayer.Repositories.IProductGroupsRepository _productGroups;
        private IProductTagsRepository _productTags;
        private IProdctSelectedGroupsRepository _prodctSelectedGroups;
        private IProductGalleriesRepository _productGalleries;
        private IProductFeaturesRepository _productFeatures;
        private IFeaturesRepository _features;
        private IProductCommentsRepository _productComments;
        private IUsersRepository _users;
        public ProductController()
        {
            _products = new ProductsRepository(db);
            _productGroups = new ProductGroupsRepository(db);
            _productTags = new ProductTagsRepository(db);
            _prodctSelectedGroups = new ProdctSelectedGroupsRepository(db);
            _productGalleries = new ProductGalleriesRepository(db);
            _productFeatures = new ProductFeaturesRepository(db);
            _features = new FeaturesRepository(db);
            _productComments = new ProductCommentsRepository(db);
            _users = new UsersRepository(db);
        }
        public ActionResult ShowGroups()
        {
            try
            {
                return PartialView(_productGroups.GetAllProductGroups());
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }


        public ActionResult LastProduct()
        {
            try
            {
                return PartialView(_products.GetAllProducts().OrderByDescending(p => p.CreateDate).Take(12));
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        [Route("ShowProduct/{id}")]
        public ActionResult ShowProduct(int id)
        {
            try
            {
                var product = _products.GetProductById(id);
                ViewBag.ProductFeatures = product.Product_Features.DistinctBy(f => f.FeatureID).Select(f => new ShowProductFeatureViewModel()
                {
                    FeatureTitle = f.Features.FeatureTitle,
                    Values = _productFeatures.GetAllProductFeatures().Where(fe => fe.FeatureID == f.FeatureID && fe.ProductID == f.ProductID).Select(fe => fe.Value).ToList()
                }).ToList();

                if (product == null)
                {
                    return HttpNotFound();
                }
                return View(product);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        public ActionResult ShowComments(int id)
        {
            try
            {
                return PartialView(_productComments.GetAllProductComments().Where(c => c.ProductID == id));
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        [HttpPost]
        public ActionResult DeleteComments(int id)
        {
            try
            {
                bool delete = _productComments.DeleteProductComment(id);
                if (delete)
                {
                    return Json(new { success = true, responseText = " حذف شد" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { success = false, responseText = "خطا در حذف " }, JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        public ActionResult CreateComment(int id)
        {
            try
            {
                return PartialView(new Product_Comments()
                {
                    ProductID = id,
                });
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        [HttpPost]
        public ActionResult CreateComment(Product_Comments productComment)
        {
            try
            {
                if (User.Identity.IsAuthenticated)
                {
                    var user = _users.GetUserByUserName(User.Identity.Name);
                    productComment.Email = user.Email;
                    productComment.Name = user.UserName;
                }
                if (ModelState.IsValid)
                {

                    productComment.CreateDate = DateTime.Now;
                    _productComments.InsertProductComment(productComment);
                    return PartialView("ShowComments", _productComments.GetAllProductComments().Where(c => c.ProductID == productComment.ProductID));
                }
                return PartialView(productComment);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        [Route("Archive")]
        public ActionResult ArchiveProduct(int pageId = 1, string title = "", int minPrice = 0, int maxPrice = 0, List<int> selectedGroups = null)
        {
            try
            {
                ViewBag.Groups = _productGroups.GetAllProductGroups();
                ViewBag.productTitle = title;
                ViewBag.minPrice = minPrice;
                ViewBag.maxPrice = maxPrice;
                ViewBag.pageId = pageId;
                ViewBag.selectGroup = selectedGroups;
                List<Products> list = new List<Products>();
                if (selectedGroups != null && selectedGroups.Any())
                {
                    foreach (int group in selectedGroups)
                    {
                        list.AddRange(_prodctSelectedGroups.GetAllProdctSelectedGroups().Where(g => g.GroupID == group).Select(g => g.Products).ToList());
                    }
                    list = list.Distinct().ToList();
                }
                else
                {
                    list.AddRange(_products.GetAllProducts());
                }


                if (title != "")
                {
                    list = list.Where(p => p.Title.Contains(title)).ToList();
                }
                if (minPrice > 0)
                {
                    list = list.Where(p => p.Price >= minPrice).ToList();
                }
                if (maxPrice > 0)
                {
                    list = list.Where(p => p.Price <= maxPrice).ToList();
                }

                //Pagging
                int take = 12;
                //int skip = (pageId - 1) * take;
                //ViewBag.PageCount = list.Count() / take;
                // return View(list.OrderByDescending(p => p.CreateDate).Skip(skip).Take(take).ToList());
                ViewBag.PageCount = list.Count() / take;
                return View(list.OrderByDescending(p => p.CreateDate).ToList());
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
    }
}