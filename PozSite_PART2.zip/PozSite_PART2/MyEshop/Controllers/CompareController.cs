﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using DataLayer.Repositories;
using DataLayer.Services;
using DataLayer.ViewModels;

namespace MyEshop.Controllers
{
    public class CompareController : Controller
    {
        DataLayer.asamedc1_bazarjeEntities db = new DataLayer.asamedc1_bazarjeEntities();
        private IProductFeaturesRepository _productFeatures;
        private IProductsRepository _products;
        public CompareController()
        {
            _productFeatures = new ProductFeaturesRepository(db);
            _products = new ProductsRepository(db);
        }
        // GET: Compare
        public ActionResult Index()
        {
            try
            {
                List<CompareItem> list = new List<CompareItem>();
                if (Session["Compare"] != null)
                {
                    list = Session["Compare"] as List<CompareItem>;
                }
                List<DataLayer.Features> features = new List<DataLayer.Features>();
                List<DataLayer.Product_Features> productFeatures = new List<DataLayer.Product_Features>();
                foreach (var item in list)
                {
                    features.AddRange(_productFeatures.GetAllProductFeatures().Where(p => p.ProductID == item.ProductID).Select(f => f.Features).ToList());
                    productFeatures.AddRange(_productFeatures.GetAllProductFeatures().Where(p => p.ProductID == item.ProductID).ToList());
                }
                ViewBag.features = features.Distinct().ToList();
                ViewBag.productFeatures = productFeatures;
                return View(list);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        public ActionResult AddToCompare(int id)
        {
            try
            {
                List<CompareItem> list = new List<CompareItem>();
                if (Session["Compare"] != null)
                {
                    list = Session["Compare"] as List<CompareItem>;
                }
                if (!list.Any(p => p.ProductID == id))
                {
                    var product = _products.GetAllProducts().Where(p => p.ProductID == id).Select(p => new { p.Title, p.ImageName }).Single();
                    list.Add(new CompareItem()
                    {
                        ProductID = id,
                        Title = product.Title,
                        ImageName = product.ImageName
                    });
                }
                Session["Compare"] = list;
                return PartialView("ListCompare", list);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        public ActionResult ListCompare()
        {
            try
            {
                List<CompareItem> list = new List<CompareItem>();
                if (Session["Compare"] != null)
                {
                    list = Session["Compare"] as List<CompareItem>;
                }
                return PartialView(list);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        public ActionResult DeleteFromCompare(int id)
        {
            try
            {
                List<CompareItem> list = new List<CompareItem>();
                if (Session["Compare"] != null)
                {
                    list = Session["Compare"] as List<CompareItem>;
                    int index = list.FindIndex(p => p.ProductID == id);
                    list.RemoveAt(index);
                    Session["Compare"] = list;
                }
                return PartialView("ListCompare", list);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
    }
}