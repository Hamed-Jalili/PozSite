﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using DataLayer.Repositories;
using DataLayer.Services;

namespace MyEshop.Controllers
{
    public class DiscountController : Controller
    {
        asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private IDiscountRepository _discount;
        public DiscountController()
        {
            _discount = new DiscountRepository(db);
        }
        // GET: Discount
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CheckDiscount(string name)
        {
            try
            {
                List<Discount> discout = _discount.GetAllDiscounts().Where(i => i.Name == name && i.Count != 0).ToList();
                if (discout.Count > 0)
                {
                    return Json(new { success = true, responseText = discout[0].Percentage, responseId = discout[0].DiscountID }, JsonRequestBehavior.AllowGet);
                }
                return Json(new { success = false, responseText = "کد تخفیف موجود نیست" }, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
    }
}