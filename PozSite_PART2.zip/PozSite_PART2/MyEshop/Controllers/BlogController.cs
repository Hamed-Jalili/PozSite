﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using DataLayer.Repositories;
using DataLayer.Services;

namespace MyEshop.Controllers
{
    public class BlogController : Controller
    {
        asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private IBlogRepository _blog;
        private IBlogGroupsRepository _blogGroups;
        public BlogController()
        {
            _blog = new BlogRepository(db);
            _blogGroups = new BlogGroupsRepository(db);
        }
        // GET: Blog
        public ActionResult Blogs(int? id)
        {
            try
            {
                var blog = id;
                if (blog == null)
                {
                    ViewBag.Name = "همه مقاله ها";
                    return View(_blog.GetAllBlogs().OrderByDescending(i => i.DatePosted));
                };
                var name = _blog.GetBlogsByGroupId(id.Value).OrderByDescending(i => i.DatePosted);
                ViewBag.Name = _blogGroups.GetBlogGroupById(id.Value).GroupeTitle;
                return View(name);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        public ActionResult ViewGroupsBlogs()
        {
            try
            {
                return PartialView(_blogGroups.GetAllBlogGroups());
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        public ActionResult BlogView(int id)
        {
            try
            {
                return View(_blog.GetblogById(id));
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        public ActionResult BlogCarousel()
        {
            try
            {
                return PartialView(_blog.GetBlogsByIsSuggested().OrderByDescending(r => Guid.NewGuid()).Take(15));
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
    }
}