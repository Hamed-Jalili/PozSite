﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using DataLayer.Repositories;
using DataLayer.Services;
using DataLayer.ViewModels;
using MyEshop.Utilities;

namespace MyEshop.Controllers
{
    public class HomeController : Controller
    {
        asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private ISliderRepository _slider;
        private IProductGalleriesRepository _productGalleries;
        private IAdRepository _ad;
        private IOnlineOrderRepository _onlineOrder;
        private IUsersRepository _users;
        private ITicketRepository _ticket;
        private ITicketImageRepository _ticketImage;
        private IConfigRepository _config;
        public HomeController()
        {
            _slider = new SliderRepository(db);
            _productGalleries = new ProductGalleriesRepository(db);
            _ad = new AdRepository(db);
            _onlineOrder = new OnlineOrderRepository(db);
            _users = new UsersRepository(db);
            _ticket = new TicketRepository(db);
            _ticketImage = new TicketImageRepository(db);
            _config = new ConfigRepository(db);
        }
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Slider()
        {
            try
            {
                DateTime dt = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0);
                return PartialView(_slider.GetAllSliders().Where(s => s.IsActive && s.StartDate <= dt && s.EndDate >= dt));
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }


        public ActionResult VisitSite()
        {
            try
            {
                DateTime dtNow = DateTime.Now.Date;
                DateTime yesterday = dtNow.AddDays(-1);
                VisitSiteViewModel visit = new VisitSiteViewModel();
                visit.VisitSum = db.SiteVisit.Count();
                visit.VisitToday = db.SiteVisit.Count(v => v.Date == dtNow);
                visit.VisitYesterday = db.SiteVisit.Count(v => v.Date == yesterday);
                visit.online = int.Parse(HttpContext.Application["Online"].ToString());
                return PartialView(visit);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        public ActionResult ViewAd()
        {
            try
            {
                return PartialView(_ad.GetAdsByRandoms());
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        public ActionResult MakeOffer()
        {
            try
            {
                return View();
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        [HttpPost]
        public ActionResult MakeOffer(OnlineOrderViewModel onlineOrder)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var userId = _users.GetUserByUserName(User.Identity.Name);
                    _onlineOrder.InsertOnlineOrder(new OnlineOrder
                    {
                        Body = onlineOrder.Body,
                        DateSubmited = DateTime.Now,
                        Title = onlineOrder.Title,
                        UserID = userId.UserID,
                    });
                    return View("Index");
                }
                return View(onlineOrder);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        public ActionResult MakeTicket()
        {
            try
            {
                return View();
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        [HttpPost]
        public ActionResult MakeTicket(TicketViewModel ticket, HttpPostedFileBase imgTicket)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var user = _users.GetUserByUserName(User.Identity.Name);
                    Ticket addTicket = new Ticket()
                    {
                        Body = ticket.Body,
                        Title = ticket.Title,
                        UserID = user.UserID,
                        Email = user.Email,
                        DateSubmited = DateTime.Now,

                    };
                    _ticket.InsertTicket(addTicket);
                    if (imgTicket != null && imgTicket.IsImage())
                    {
                        Ticket_Image addTicketImage = new Ticket_Image();

                        addTicketImage.ImageName = Guid.NewGuid().ToString() + Path.GetExtension(imgTicket.FileName);
                        imgTicket.SaveAs(Server.MapPath("/Images/Ticket/" + addTicketImage.ImageName));
                        addTicketImage.TicketID = addTicket.TicketID;
                        addTicketImage.Title = ticket.Title;
                        _ticketImage.InsertTicketImage(addTicketImage);
                    };
                    return View("Index");
                }
                return View(ticket);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        public ActionResult About()
        {
            return View(_config.SelectConfigById(1));
        }
        public ActionResult Contact()
        {
            return View(_config.SelectConfigById(1));
        }
        public ActionResult Policies()
        {
            return View(_config.SelectConfigById(1));
        }
        public ActionResult Gallery()
        {
            try
            {
                return View(_productGalleries.GetAllProductGalleries().OrderByDescending(i => i.GalleryID));
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
    }
}