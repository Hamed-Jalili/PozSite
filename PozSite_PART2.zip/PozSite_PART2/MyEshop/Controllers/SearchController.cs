﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using DataLayer.Repositories;
using DataLayer.Services;
using DataLayer.ViewModels;

namespace MyEshop.Controllers
{
    public class SearchController : Controller
    {
        asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private IProductsRepository _products;
        private IProductTagsRepository _productTags;
        public SearchController()
        {
            _products = new ProductsRepository(db);
            _productTags = new ProductTagsRepository(db);
        }
        public ActionResult Index(string q)
        {
            try
            {
                List<Products> list = new List<Products>();
                list.AddRange(_productTags.GetAllProductTags().Where(t => t.Tag == q).Select(t => t.Products).ToList());
                list.AddRange(_products.GetAllProducts().Where(p => p.Title.Contains(q) || p.ShortDescription.Contains(q) || p.Text.Contains(q)).ToList());
                ViewBag.search = q;
                return View(list.Distinct());
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
    }
}