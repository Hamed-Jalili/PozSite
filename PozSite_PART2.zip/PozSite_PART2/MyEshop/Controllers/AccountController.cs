﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using DataLayer.ViewModels;
using System.Web.Security;
using System.Text;
using DataLayer.Repositories;
using DataLayer.Services;
using DataLayer.Utilities;
using MyEshop.Utilities;

namespace MyEshop.Controllers
{
    public class AccountController : Controller
    {
        asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private IUsersRepository _users;
        public AccountController()
        {
            _users = new UsersRepository(db);
        }
        // GET: Account
        [Route("Register")]
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [Route("Register")]
        [ValidateAntiForgeryToken]
        public ActionResult Register(RegisterViewModel register , FormCollection form)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (!MethodRepo.CheckRechapcha(form))
                    {
                        ViewBag.Message = "لطفا گزینه من ربات نیستم را تکمیل کنید";
                        return View(register);
                    }
                    if (_users.GetAllUsers().Any(u => u.UserName == register.UserName.ToLower()))
                    {
                        ModelState.AddModelError("UserName", "نام کاربری وارد شده تکراری است");
                        return View(register);

                    }
                    if (!_users.GetAllUsers().Any(u => u.Email == register.Email.Trim().ToLower()))
                    {
                        Users user = new Users()
                        {
                            Email = register.Email.Trim().ToLower(),
                            Password = FormsAuthentication.HashPasswordForStoringInConfigFile(register.Password, "MD5"),
                            ActiveCode = Guid.NewGuid().ToString(),
                            IsActive = false,
                            RegisterDate = DateTime.Now,
                            RoleID = 1,
                            UserName = register.UserName
                        };
                        _users.InsertUser(user);
                        //Send Active Email
                        string body = PartialToStringClass.RenderPartialView("ManageEmails", "ActiviationEmail", user);
                        SendEmail.Send(user.Email, "ایمیل فعالسازی", body);
                        //End Send Active Email
                        return View("SuccessRegister", user);
                    }
                    else
                    {
                        ModelState.AddModelError("Email", "ایمیل وارد شده تکراری است");
                    }
                }
                return View(register);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        [Route("Login")]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [Route("Login")]
        public ActionResult Login(LoginViewModel login, FormCollection form, string ReturnUrl = "/")
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (!MethodRepo.CheckRechapcha(form))
                    {
                        ViewBag.Message = "لطفا گزینه من ربات نیستم را تکمیل کنید";
                        return View(login);
                    }
                    string hashPassword = FormsAuthentication.HashPasswordForStoringInConfigFile(login.Password, "MD5");
                    var user = _users.GetAllUsers().SingleOrDefault(u => u.Email == login.Email && u.Password == hashPassword);
                    if (user != null)
                    {
                        if (user.IsActive)
                        {
                            FormsAuthentication.SetAuthCookie(user.UserName, login.RememberMe);
                            //FormsAuthentication.SetAuthCookie(user.UserName + "|" + user.Email + "|" + user.RoleID + "|" + user.UserID, login.RememberMe);
                            return Redirect(ReturnUrl);
                        }
                        else
                        {
                            ModelState.AddModelError("Email", "حساب کاربری شما فعال نشده است");
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("Email", "کاربری با اطلاعات وارد شده یافت نشد");
                    }
                }
                return View(login);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        public ActionResult ActiveUser(string id)
        {
            try
            {
                var user = _users.GetAllUsers().SingleOrDefault(u => u.ActiveCode == id);
                if (user == null)
                {
                    return HttpNotFound();
                }
                user.IsActive = true;
                user.ActiveCode = Guid.NewGuid().ToString();
                ViewBag.UserName = user.UserName;
                return View();
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        public ActionResult LogOff()
        {
            try
            {
                FormsAuthentication.SignOut();
                return Redirect("/");
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        [Route("ForgotPassword")]
        public ActionResult ForgotPassword()
        {
            try
            {
                return View();
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }


        [Route("ForgotPassword")]
        [HttpPost]
        public ActionResult ForgotPassword(ForgotPasswordViewModel forgot, FormCollection form)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (!MethodRepo.CheckRechapcha(form))
                    {
                        ViewBag.Message = "لطفا گزینه من ربات نیستم را تکمیل کنید";
                        return View(forgot);
                    }
                    var user = _users.GetAllUsers().SingleOrDefault(u => u.Email == forgot.Email);
                    if (user != null)
                    {
                        if (user.IsActive)
                        {
                            string bodyEmail =
                                PartialToStringClass.RenderPartialView("ManageEmails", "RecoveryPassword", user);
                            SendEmail.Send(user.Email, "بازیابی کلمه عبور", bodyEmail);
                            return View("SuccesForgotPassword", user);
                        }
                        else
                        {
                            ModelState.AddModelError("Email", "حساب کاربری شما فعال نیست");
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("Email", "کاربری یافت نشد");
                    }
                }
                return View();
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        public ActionResult RecoveryPassword(string id)
        {
            try
            {
                return View();
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        [HttpPost]
        public ActionResult RecoveryPassword(string id, RecoveryPasswordViewModel recovery)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var user = _users.GetAllUsers().SingleOrDefault(u => u.ActiveCode == id);
                    if (user == null)
                    {
                        return HttpNotFound();
                    }
                    user.Password = FormsAuthentication.HashPasswordForStoringInConfigFile(recovery.Password, "MD5");
                    user.ActiveCode = Guid.NewGuid().ToString();
                    _users.UpdateUser(user);
                    return Redirect("/Login?recovery=true");
                }
                return View();
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
    }
}