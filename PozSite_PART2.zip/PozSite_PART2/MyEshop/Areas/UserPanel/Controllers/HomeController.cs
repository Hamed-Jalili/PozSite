﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using DataLayer.Repositories;
using DataLayer.Services;
using DataLayer.ViewModels;

namespace MyEshop.Areas.UserPanel.Controllers
{
    public class HomeController : Controller
    {
        asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private IUsersRepository _users;
        private IOrderDetailsRepository _orderDetails;
        private IOrdersRepository _orders;
        private IProductsRepository _products;
        private IDiscountRepository _discount;
        public HomeController()
        {
            _users = new UsersRepository(db);
            _orderDetails = new OrderDetailsRepository(db);
            _orders = new OrdersRepository(db);
            _products = new ProductsRepository(db);
            _discount = new DiscountRepository(db);
        }
        // GET: UserPanel/Home
        public ActionResult Index()
        {

            return View();
        }
        public ActionResult History()
        {
            try
            {
                var usersId = _users.GetUserByUserName(User.Identity.Name);
                List<Orders> orderUser = _orders.GetOrdersByUserId(usersId.UserID);
                List<HistoryViewModel> history = new List<HistoryViewModel>();
                List<int> prices = new List<int>(orderUser.Count);
                List<int> counts = new List<int>(orderUser.Count);
                foreach (Orders i in orderUser)
                {
                    List<OrderDetails> details = _orderDetails.GetOrderDetailByOrderId(i.OrderID);
                    int priceSum = details.Sum(k => k.Price);
                    int countSum = details.Sum(k => k.Count);

                    //foreach (OrderDetails j in details)
                    //{
                    //    priceSum += j.Price;
                    //    countSum += j.Count;
                    //}
                    history.Add(new HistoryViewModel { IsFinaly = i.IsFinaly, OrderId = i.OrderID, Count = countSum, Price = priceSum, Date = i.Date });

                    //----------------
                }
                return View(history.OrderByDescending(i => i.OrderId));
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        public ActionResult FactorView(int id)
        {
            try
            {
                var order = _orders.GetOrdersById(id);
                var orderDetails = _orderDetails.GetOrderDetailByOrderId(order.OrderID);
                int discount = 0;
                if (order.DiscountId != null)
                {
                    Discount dis = _discount.GetDiscountById(Convert.ToInt32(order.DiscountId));
                    discount = dis.Percentage;
                }
                List<ShowOrderViewModel> list = new List<ShowOrderViewModel>();
                foreach (var item in orderDetails)
                {
                    var product = _products.GetAllProducts().Where(p => p.ProductID == item.ProductID).Select(p => new
                    {
                        p.ImageName,
                        p.Title,
                        p.Price
                    }).Single();

                    ShowOrderViewModel showOrder = new ShowOrderViewModel();
                    showOrder.Count = item.Count;
                    showOrder.ProductID = item.ProductID;
                    showOrder.Price = product.Price;
                    showOrder.ImageName = product.ImageName;
                    showOrder.Title = product.Title;
                    showOrder.Sum = item.Count * product.Price;
                    showOrder.Discount = discount;
                    showOrder.SumFinal = order.Sum;
                    list.Add(showOrder);
                }

                return View(list);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
    }
}