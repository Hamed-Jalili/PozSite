﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using DataLayer.Repositories;
using DataLayer.Services;
using DataLayer.ViewModels;

namespace MyEshop.Areas.UserPanel.Controllers
{
    public class TicketController : Controller
    {
        asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private IUsersRepository _users;
        private ITicketRepository _ticket;
        private ITicketImageRepository _ticketImage;
        public TicketController()
        {
            _users = new UsersRepository(db);
            _ticket = new TicketRepository(db);
            _ticketImage = new TicketImageRepository(db);
        }
        // GET: UserPanel/Ticket
        public ActionResult Index()
        {

            return View();
        }

        public ActionResult TicketBlock()
        {
            try
            {
                var usersId = _users.GetUserByUserName(User.Identity.Name);
                var allTicket = _ticket.GetTicketByUser(usersId.UserID);
                List<TicketViewModel> listTicket = new List<TicketViewModel>();
                foreach (var item in allTicket)
                {
                    var c = new TicketViewModel()
                    {
                        Body = item.Body,
                        Email = item.Email,
                        IsAdmin = item.IsAdmin,
                        IsAnswered = item.IsAnswered,
                        TicketID = item.TicketID,
                        Title = item.Title,
                        UserName = item.Users.UserName,
                        UserID = item.UserID,
                        DateSubmited = item.DateSubmited,
                    };
                    c.Image = _ticketImage.GetTicketImageByTicketId(item.TicketID)?.ImageName;
                    listTicket.Add(c);
                }
                return PartialView(listTicket);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        public ActionResult TicketView(int id)
        {
            try
            {
                Ticket ticket = _ticket.GetTicketById(id);
                TicketViewModel ticketViewModel = new TicketViewModel();
                ticketViewModel.Body = ticket.Body;
                ticketViewModel.Email = ticket.Email;
                ticketViewModel.Title = ticket.Title;
                ticketViewModel.UserName = ticket.Users.UserName;
                ticketViewModel.Image = _ticketImage.GetTicketImageByTicketId(ticket.TicketID)?.ImageName;
                ticketViewModel.DateSubmited = ticket.DateSubmited;
                ticketViewModel.UserID = ticket.UserID;
                ticketViewModel.TicketID = ticket.TicketID;
                return PartialView(ticketViewModel);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

    }
}