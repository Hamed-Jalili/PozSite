﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using DataLayer.Repositories;
using DataLayer.Services;

namespace MyEshop.Areas.Admin.Controllers
{
    public class Product_GroupsController : Controller
    {
        private asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private IProductGroupsRepository _productGroups;
        public Product_GroupsController()
        {
            _productGroups = new ProductGroupsRepository(db);
        }
        // GET: Admin/Product_Groups
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ListGroups()
        {
            try
            {
                var product_Groups = _productGroups.GetAllProductGroups().Where(g => g.ParentID == null);
                return PartialView(product_Groups.ToList());
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        // GET: Admin/Product_Groups/Details/5
        public ActionResult Details(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Product_Groups product_Groups = _productGroups.GetProductGroupsById(id.Value);
                if (product_Groups == null)
                {
                    return HttpNotFound();
                }
                return View(product_Groups);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }

        // GET: Admin/Product_Groups/Create
        public ActionResult Create(int? id)
        {
            try
            {
                return PartialView(new Product_Groups()
                {
                    ParentID = id
                });
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }

        // POST: Admin/Product_Groups/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "GroupID,GroupTitle,ParentID")] Product_Groups product_Groups)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _productGroups.InsertProductGroups(product_Groups);
                    return PartialView("ListGroups", _productGroups.GetAllProductGroups().Where(g => g.ParentID == null));
                }
                ViewBag.ParentID = new SelectList(_productGroups.GetAllProductGroups(), "GroupID", "GroupTitle", product_Groups.ParentID);
                return View(product_Groups);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }

        // GET: Admin/Product_Groups/Edit/5
        public ActionResult Edit(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Product_Groups product_Groups = _productGroups.GetProductGroupsById(id.Value);
                if (product_Groups == null)
                {
                    return HttpNotFound();
                }

                return PartialView(product_Groups);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }

        // POST: Admin/Product_Groups/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "GroupID,GroupTitle,ParentID")] Product_Groups product_Groups)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _productGroups.UpdateProductGroups(product_Groups);
                    return PartialView("ListGroups", _productGroups.GetAllProductGroups().Where(g => g.ParentID == null));
                }
                ViewBag.ParentID = new SelectList(_productGroups.GetAllProductGroups(), "GroupID", "GroupTitle", product_Groups.ParentID);
                return View(product_Groups);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }

        // GET: Admin/Product_Groups/Delete/5
        public ActionResult Delete(int id)
        {
            try
            {
                try
                {
                    var group = _productGroups.GetProductGroupsById(id);
                    bool DeleteCheck = _productGroups.GetProductGroupsBySelectGroup(id);
                    if (DeleteCheck)
                    {
                        return Json(new { success = false, responseText = "خطا در حذف  اول جنس مربوطه رو حذف کنید" }, JsonRequestBehavior.AllowGet);
                    }
                    if (group.Product_Groups1.Any())
                    {
                        foreach (var subGroup in _productGroups.GetAllProductGroups().Where(g => g.ParentID == id))
                        {
                            bool DeleteCheck2 = _productGroups.GetProductGroupsBySelectGroup(subGroup.GroupID);
                            if (DeleteCheck2)
                            {
                                return Json(new { success = false, responseText = "خطا در حذف  گروه لطفا دقت فرمایید" }, JsonRequestBehavior.AllowGet);
                            }
                            _productGroups.DeleteProductGroups(subGroup);
                        }
                    }
                    _productGroups.DeleteProductGroups(group);
                    return Json(new { success = true, responseText = "گروه حذف شد" }, JsonRequestBehavior.AllowGet);
                }
                catch
                {
                    return Json(new { success = false, responseText = "خطا در حذف  گروه لطفا دقت فرمایید" }, JsonRequestBehavior.AllowGet);

                }
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }


        }
        // POST: Admin/Product_Groups/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                try
                {
                    bool deleteChech = _productGroups.GetProductGroupsByParentId(id);
                    if (deleteChech)
                    {
                        Product_Groups product_Groups = _productGroups.GetProductGroupsById(id);
                        _productGroups.DeleteProductGroups(product_Groups);
                        return Json(new { success = false, responseText = "خطا در حذف  گروه لطفا دقت فرمایید" }, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json(new { success = true, responseText = "گروه حذف شد" }, JsonRequestBehavior.AllowGet);
                    }
                }
                catch
                {
                    return Json(new { success = false, responseText = "خطا در حذف  گروهلطفا دقت فرمایید" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }


        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
