﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using DataLayer.Repositories;
using DataLayer.Services;

namespace MyEshop.Areas.Admin.Controllers
{
    public class SlidersController : Controller
    {
        private asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private ISliderRepository _sliderRepository;
        public SlidersController()
        {
            _sliderRepository = new SliderRepository(db);
        }
        // GET: Admin/Sliders
        public ActionResult Index()
        {
            try
            {
                return View(_sliderRepository.GetAllSliders());
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // GET: Admin/Sliders/Details/5
        public ActionResult Details(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Slider slider = _sliderRepository.GetSliderById(id.Value);
                if (slider == null)
                {
                    return HttpNotFound();
                }
                return View(slider);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // GET: Admin/Sliders/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Admin/Sliders/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "SlideID,Url,Title,ImageName,StartDate,EndDate,IsActive")] Slider slider, HttpPostedFileBase imgUp)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (imgUp == null)
                    {
                        ModelState.AddModelError("ImageName", "لطفا تصویر را انتخاب کنید");
                        return View(slider);
                    }
                    slider.ImageName = Guid.NewGuid().ToString() + System.IO.Path.GetExtension(imgUp.FileName);
                    imgUp.SaveAs(Server.MapPath("/Images/Slider/" + slider.ImageName));
                    _sliderRepository.InsertSlider(slider);
                    return RedirectToAction("Index");
                }
                return View(slider);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // GET: Admin/Sliders/Edit/5
        public ActionResult Edit(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Slider slider = _sliderRepository.GetSliderById(id.Value);
                if (slider == null)
                {
                    return HttpNotFound();
                }
                return View(slider);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // POST: Admin/Sliders/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "SlideID,Title,Url,ImageName,StartDate,EndDate,IsActive")] Slider slider, HttpPostedFileBase imgUp)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (imgUp != null)
                    {
                        System.IO.File.Delete(Server.MapPath("/Images/Slider/" + slider.ImageName));
                        slider.ImageName = Guid.NewGuid().ToString() + System.IO.Path.GetExtension(imgUp.FileName);
                        imgUp.SaveAs(Server.MapPath("/Images/Slider/" + slider.ImageName));
                    }
                    _sliderRepository.UpdateSlider(slider);
                    return RedirectToAction("Index");
                }
                return View(slider);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }



        // POST: Admin/Sliders/Delete/5
        [HttpPost]
        public ActionResult Delete(int id)
        {
            try
            {
                try
                {
                    Slider slider = _sliderRepository.GetSliderById(id);
                    System.IO.File.Delete(Server.MapPath("/Images/Slider/" + slider.ImageName));
                    bool sliderDelete = _sliderRepository.DeleteSlider(slider);
                    if (sliderDelete)
                    {
                        return Json(new { success = true, responseText = " حذف شد" }, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json(new { success = false, responseText = "خطا در حذف " }, JsonRequestBehavior.AllowGet);
                    }
                }
                catch
                {
                    return Json(new { success = false, responseText = "خطا در حذف " }, JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
                _sliderRepository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
