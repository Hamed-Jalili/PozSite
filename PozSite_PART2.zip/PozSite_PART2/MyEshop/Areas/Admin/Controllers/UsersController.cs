﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using DataLayer;
using DataLayer.Repositories;
using DataLayer.Services;
using DataLayer.ViewModels;

namespace MyEshop.Areas.Admin.Controllers
{
    //[Authorize(Roles = "admin")]
    public class UsersController : Controller
    {
        private asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private IUsersRepository _usersRepository;
        private IRolesRepository _rolesRepository;
        public UsersController()
        {
            _usersRepository = new UsersRepository(db);
            _rolesRepository = new RolesRepository(db);
        }

        // GET: Admin/Users
        public ActionResult Index()
        {
            try
            {
                return View(_usersRepository.GetAllUsers());
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        // GET: Admin/Users/Details/5
        public ActionResult Details(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Users users = _usersRepository.GetUserById(id.Value);
                if (users == null)
                {
                    return HttpNotFound();
                }
                return View(users);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // GET: Admin/Users/Create
        public ActionResult Create()
        {
            try
            {
                ViewBag.RoleID = new SelectList(_rolesRepository.GetAllRoles(), "RoleID", "RoleTitle");
                return View();
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // POST: Admin/Users/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "UserID,RoleID,UserName,Email,Password,IsActive,RePassword")] RegisterViewModel register)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (_usersRepository.GetAllUsers().Any(u => u.UserName == register.UserName.ToLower()))
                    {
                        ViewBag.RoleID = new SelectList(_rolesRepository.GetAllRoles(), "RoleID", "RoleTitle", register.RoleID);
                        ModelState.AddModelError("UserName", "نام کاربری وارد شده تکراری است");
                        return View(register);

                    }
                    if (!_usersRepository.GetAllUsers().Any(u => u.Email == register.Email.Trim().ToLower()))
                    {
                        Users user = new Users()
                        {
                            Email = register.Email.Trim().ToLower(),
                            Password = FormsAuthentication.HashPasswordForStoringInConfigFile(register.Password, "MD5"),
                            ActiveCode = Guid.NewGuid().ToString(),
                            IsActive = register.IsActive,
                            RegisterDate = DateTime.Now,
                            RoleID = 1,
                            UserName = register.UserName
                        };
                        _usersRepository.InsertUser(user);
                        return RedirectToAction("Index");

                    }
                    else
                    {
                        ViewBag.RoleID = new SelectList(_rolesRepository.GetAllRoles(), "RoleID", "RoleTitle", register.RoleID);
                        ModelState.AddModelError("Email", "ایمیل وارد شده تکراری است");
                    }

                }
                ViewBag.RoleID = new SelectList(_rolesRepository.GetAllRoles(), "RoleID", "RoleTitle", register.RoleID);
                return View(register);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // GET: Admin/Users/Edit/5
        public ActionResult Edit(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Users users = _usersRepository.GetUserById(id.Value);
                if (users == null)
                {
                    return HttpNotFound();
                }
                RegisterViewModel userViewModel = new RegisterViewModel()
                {
                    ActiveCode = users.ActiveCode,
                    Email = users.Email,
                    UserID = users.UserID,
                    UserName = users.UserName,
                    Password = users.Password,
                    IsActive = users.IsActive,
                    RegisterDate = users.RegisterDate,
                    RoleID = users.RoleID,
                    RePassword = users.Password,
                };
                ViewBag.RoleID = new SelectList(_rolesRepository.GetAllRoles(), "RoleID", "RoleTitle", users.RoleID);
                return View(userViewModel);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // POST: Admin/Users/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "UserID,RoleID,UserName,Email,Password,IsActive,RePassword")] RegisterViewModel register)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (_usersRepository.GetAllUsers().Where(i => i.UserID != register.UserID).Any(u => u.UserName == register.UserName.ToLower()))
                    {
                        ModelState.AddModelError("UserName", "نام کاربری وارد شده تکراری است");
                        return View(register);

                    }
                    if (!_usersRepository.GetAllUsers().Where(i => i.UserID != register.UserID).Any(u => u.Email == register.Email.Trim().ToLower()))
                    {

                        Users user = new Users()
                        {
                            UserID = register.UserID,
                            Email = register.Email.Trim().ToLower(),
                            Password = register.Password,
                            ActiveCode = Guid.NewGuid().ToString(),
                            IsActive = register.IsActive,
                            RegisterDate = DateTime.Now,
                            RoleID = register.RoleID,
                            UserName = register.UserName
                        };
                        _usersRepository.UpdateUser(user);
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ModelState.AddModelError("Email", "ایمیل وارد شده تکراری است");
                    }

                }
                ViewBag.RoleID = new SelectList(_rolesRepository.GetAllRoles(), "RoleID", "RoleTitle", register.RoleID);
                return View(register);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // GET: Admin/Users/Delete/5
        //public ActionResult Delete(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    Users users = _usersRepository.GetUserById(id.Value);
        //    if (users == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(users);
        //}

        //// POST: Admin/Users/Delete/5
        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public ActionResult DeleteConfirmed(int id)
        //{
        //    Users users = _usersRepository.GetUserById(id);
        //    _usersRepository.DeleteUser(users);
        //    return RedirectToAction("Index");
        //}
        [HttpPost]
        public ActionResult Delete(int id)
        {
            try
            {
                try
                {
                    Users users = _usersRepository.GetUserById(id);
                    bool userDelete = _usersRepository.DeleteUser(users);
                    if (userDelete)
                    {
                        return Json(new { success = true, responseText = " حذف شد" }, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json(new { success = false, responseText = "خطا در حذف " }, JsonRequestBehavior.AllowGet);
                    }
                }
                catch
                {
                    return Json(new { success = false, responseText = "خطا در حذف " }, JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
                _usersRepository.Dispose();
                _rolesRepository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
