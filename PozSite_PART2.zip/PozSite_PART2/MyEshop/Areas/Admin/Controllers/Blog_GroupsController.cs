﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using DataLayer.Repositories;
using DataLayer.Services;

namespace MyEshop.Areas.Admin.Controllers
{
    public class Blog_GroupsController : Controller
    {
        // GET: Admin/Blog_Groups
        private asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private IBlogGroupsRepository _blogGroupsRepository;
        public Blog_GroupsController()
        {
            _blogGroupsRepository = new BlogGroupsRepository(db);
        }
        // GET: Admin/Blog_Groups
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ListGroups()
        {
            try
            {
                var Blog_Groups = _blogGroupsRepository.GetAllBlogGroups();
                return PartialView(Blog_Groups.ToList());
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        // GET: Admin/Blog_Groups/Details/5
        public ActionResult Details(int? id)
        {
            try
            {
                if (id == null)
                {
                    return RedirectToAction("/ErrorPage/NotFound");
                }
                Blog_Groups Blog_Groups = _blogGroupsRepository.GetBlogGroupById(id.Value);
                if (Blog_Groups == null)
                {
                    return HttpNotFound();
                }
                return View(Blog_Groups);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // GET: Admin/Blog_Groups/Create
        public ActionResult Create()
        {
            return PartialView();
        }

        // POST: Admin/Blog_Groups/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "GroupeTitle")] Blog_Groups blog_Groups)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _blogGroupsRepository.InsertBlogGroup(blog_Groups);
                    return PartialView("ListGroups", _blogGroupsRepository.GetAllBlogGroups());
                }
                return View(blog_Groups);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // GET: Admin/Blog_Groups/Edit/5
        public ActionResult Edit(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Blog_Groups Blog_Groups = _blogGroupsRepository.GetBlogGroupById(id.Value);
                if (Blog_Groups == null)
                {
                    return HttpNotFound();
                }

                return PartialView(Blog_Groups);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // POST: Admin/Blog_Groups/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "GroupID,GroupeTitle")] Blog_Groups blog_Groups)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _blogGroupsRepository.UpdateBlogGroup(blog_Groups);
                    return PartialView("ListGroups", _blogGroupsRepository.GetAllBlogGroups());
                }
                return View(blog_Groups);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // GET: Admin/Blog_Groups/Delete/5
        public ActionResult Delete(int id)
        {
            try
            {
                var group = _blogGroupsRepository.GetBlogGroupById(id);
                _blogGroupsRepository.DeleteBlogGroup(group);
                return RedirectToAction("Index");
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // POST: Admin/Blog_Groups/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                Blog_Groups Blog_Groups = _blogGroupsRepository.GetBlogGroupById(id);
                _blogGroupsRepository.DeleteBlogGroup(Blog_Groups);
                return RedirectToAction("Index");
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
                _blogGroupsRepository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}