﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using DataLayer.Services;
using DataLayer.ViewModels;
using InsertShowImage;
using KooyWebApp_MVC.Classes;

namespace MyEshop.Areas.Admin.Controllers
{
    public class ProductsController : Controller
    {
        private asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private IProductsRepository _products;
        private IProductGroupsRepository _productGroups;
        private IProductTagsRepository _productTags;
        private IProdctSelectedGroupsRepository _prodctSelectedGroupsRepository;
        private IProductGalleriesRepository _productGalleriesRepository;
        private IProductFeaturesRepository _productFeaturesRepository;
        private IFeaturesRepository _featuresRepository;
        public ProductsController()
        {
            _products = new ProductsRepository(db);
            _productGroups = new ProductGroupsRepository(db);
            _productTags = new ProductTagsRepository(db);
            _prodctSelectedGroupsRepository = new ProdctSelectedGroupsRepository(db);
            _productGalleriesRepository = new ProductGalleriesRepository(db);
            _productFeaturesRepository = new ProductFeaturesRepository(db);
            _featuresRepository = new FeaturesRepository(db);
        }

        // GET: Admin/Products
        public ActionResult Index()
        {
            try
            {
                return View(_products.GetAllProducts().OrderByDescending(i => i.ProductID));
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // GET: Admin/Products/Details/5
        public ActionResult Details(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Products products = _products.GetProductById(id.Value);
                if (products == null)
                {
                    return HttpNotFound();
                }
                return View(products);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // GET: Admin/Products/Create
        public ActionResult Create()
        {
            try
            {
                ViewBag.Groups = _productGroups.GetAllProductGroups();
                return View();
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // POST: Admin/Products/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ProductID,Title,ShortDescription,Text,Price,ImageName")] ProductViewModel products, List<int> selectedGroups, HttpPostedFileBase imageProduct, string tags)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (selectedGroups == null)
                    {
                        ViewBag.ErrorSelectedGroup = true;
                        ViewBag.Groups = _productGroups.GetAllProductGroups();
                        return View(products);
                    }
                    products.ImageName = "images.jpg";
                    if (imageProduct != null && imageProduct.IsImage())
                    {
                        products.ImageName = Guid.NewGuid().ToString() + Path.GetExtension(imageProduct.FileName);
                        imageProduct.SaveAs(Server.MapPath("/Images/ProductImages/" + products.ImageName));
                        ImageResizer img = new ImageResizer();
                        img.Resize(Server.MapPath("/Images/ProductImages/" + products.ImageName),
                            Server.MapPath("/Images/ProductImages/Thumb/" + products.ImageName));
                    }
                    products.CreateDate = DateTime.Now;
                    Products addProducts = new Products()
                    {
                        CreateDate = products.CreateDate,
                        ImageName = products.ImageName,
                        Price = products.Price,
                        ShortDescription = products.ShortDescription,
                        Text = products.Text,
                        Title = products.Title,
                    };
                    _products.InsertProduct(addProducts);
                    foreach (int selectedGroup in selectedGroups)
                    {
                        Prodct_Selected_Groups prodct_Selected_Groups = new Prodct_Selected_Groups();
                        prodct_Selected_Groups.ProductID = addProducts.ProductID;
                        prodct_Selected_Groups.GroupID = selectedGroup;
                        _prodctSelectedGroupsRepository.InsertProdctSelectedGroup(prodct_Selected_Groups);
                    }

                    if (!string.IsNullOrEmpty(tags))
                    {
                        string[] tag = tags.Split('.');
                        foreach (string t in tag)
                        {
                            _productTags.InsertProductTags(new Product_Tags()
                            {
                                ProductID = addProducts.ProductID,
                                Tag = t.Trim()
                            });
                        }
                    }
                    return RedirectToAction("Index");
                }
                ViewBag.Groups = _productGroups.GetAllProductGroups();
                return View(products);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // GET: Admin/Products/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Products products = _products.GetProductById(id.Value);
            if (products == null)
            {
                return HttpNotFound();
            }
            ProductViewModel productViewModel = new ProductViewModel()
            {
                CreateDate = products.CreateDate,
                ImageName = products.ImageName,
                Price = products.Price,
                ProductID = products.ProductID,
                ShortDescription = products.ShortDescription,
                Text = products.Text,
                Title = products.Title
            };

            ViewBag.SelectedGroups = products.Prodct_Selected_Groups.ToList();
            ViewBag.Groups = _productGroups.GetAllProductGroups();
            ViewBag.Tags = string.Join(".", products.Product_Tags.Select(t => t.Tag).ToList());
            return View(productViewModel);
        }

        // POST: Admin/Products/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ProductID,Title,ShortDescription,Text,Price,ImageName,CreateDate")] ProductViewModel products, List<int> selectedGroups, HttpPostedFileBase imageProduct, string tags)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (selectedGroups == null)
                    {
                        Products products3 = _products.GetProductById(products.ProductID);
                        ViewBag.SelectedGroups = products3.Prodct_Selected_Groups.ToList();
                        ViewBag.ErrorSelectedGroup = true;
                        ViewBag.Groups = _productGroups.GetAllProductGroups();
                        return View(products);
                    }
                    if (imageProduct != null && imageProduct.IsImage())
                    {
                        if (products.ImageName != "NoImg.svg")
                        {
                            System.IO.File.Delete(Server.MapPath("/Images/ProductImages/" + products.ImageName));
                            System.IO.File.Delete(Server.MapPath("/Images/ProductImages/Thumb/" + products.ImageName));
                        }

                        products.ImageName = Guid.NewGuid().ToString() + Path.GetExtension(imageProduct.FileName);
                        imageProduct.SaveAs(Server.MapPath("/Images/ProductImages/" + products.ImageName));
                        ImageResizer img = new ImageResizer();
                        img.Resize(Server.MapPath("/Images/ProductImages/" + products.ImageName),
                            Server.MapPath("/Images/ProductImages/Thumb/" + products.ImageName));
                    }
                    Products productsUpdate = new Products()
                    {
                        ProductID = products.ProductID,
                        Price = products.Price,
                        CreateDate = products.CreateDate,
                        ImageName = products.ImageName,
                        ShortDescription = products.ShortDescription,
                        Text = products.Text,
                        Title = products.Title,
                    };
                    _products.UpdateProduct(productsUpdate);
                    _productTags.GetAllProductTags().Where(t => t.ProductID == productsUpdate.ProductID).ToList().ForEach(t => _productTags.DeleteProductTags(t));
                    if (!string.IsNullOrEmpty(tags))
                    {
                        string[] tag = tags.Split('.');
                        foreach (string t in tag)
                        {
                            _productTags.InsertProductTags(new Product_Tags()
                            {
                                ProductID = productsUpdate.ProductID,
                                Tag = t.Trim()
                            });
                        }
                    }


                    _prodctSelectedGroupsRepository.GetAllProdctSelectedGroups().Where(g => g.ProductID == productsUpdate.ProductID).ToList().ForEach(g => _prodctSelectedGroupsRepository.DeleteProdctSelectedGroup(g));
                    if (selectedGroups != null && selectedGroups.Any())
                    {
                        foreach (int selectedGroup in selectedGroups)
                        {
                            _prodctSelectedGroupsRepository.InsertProdctSelectedGroup(new Prodct_Selected_Groups()
                            {
                                ProductID = productsUpdate.ProductID,
                                GroupID = selectedGroup
                            });
                        }
                    }

                    return RedirectToAction("Index");
                }
                Products products34 = _products.GetProductById(products.ProductID);
                ViewBag.SelectedGroups = products34.Prodct_Selected_Groups.ToList();

                //ViewBag.SelectedGroups = selectedGroups;
                ViewBag.Groups = _productGroups.GetAllProductGroups();
                ViewBag.Tags = tags;
                return View(products);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // GET: Admin/Products/Delete/5
        public ActionResult Delete(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Products products = _products.GetProductById(id.Value);
                if (products == null)
                {
                    return HttpNotFound();
                }
                return View(products);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // POST: Admin/Products/Delete/5
        [HttpPost]
        public ActionResult Delete(int id)
        {
            try
            {
                try
                {
                    var deleteGalerie = _productGalleriesRepository.GetProductGallerieByProductId(id);
                    foreach (var item in deleteGalerie)
                    {
                        System.IO.File.Delete(Server.MapPath("/Images/ProductImages/" + item.ImageName));
                        System.IO.File.Delete(Server.MapPath("/Images/ProductImages/Thumb/" + item.ImageName));
                    }
                    bool products = _products.DeleteProduct(id);
                    if (products)
                    {
                        return Json(new { success = true, responseText = "جنس حذف شد" }, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json(new { success = false, responseText = "خطا در حذف جنس" }, JsonRequestBehavior.AllowGet);
                    }
                }
                catch (Exception e)
                {
                    return Json(new { success = false, responseText = "خطا در حذف جنس" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }


        #region Gallery

        public ActionResult Gallery(int id)
        {
            try
            {
                ViewBag.Galleries = _productGalleriesRepository.GetAllProductGalleries().Where(p => p.ProductID == id).ToList();
                return View(new Product_Galleries()
                {
                    ProductID = id
                });
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        [HttpPost]
        public ActionResult Gallery(Product_Galleries galleries, HttpPostedFileBase imgUp)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (imgUp != null && imgUp.IsImage())
                    {
                        galleries.ImageName = Guid.NewGuid().ToString() + Path.GetExtension(imgUp.FileName);
                        imgUp.SaveAs(Server.MapPath("/Images/ProductImages/" + galleries.ImageName));
                        ImageResizer img = new ImageResizer();
                        img.Resize(Server.MapPath("/Images/ProductImages/" + galleries.ImageName),
                            Server.MapPath("/Images/ProductImages/Thumb/" + galleries.ImageName));
                        _productGalleriesRepository.InsertProductGallerie(galleries);
                    }
                }
                return RedirectToAction("Gallery", new { id = galleries.ProductID });
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        public ActionResult DeleteGallery(int id)
        {
            try
            {
                var gallery = _productGalleriesRepository.GetProductGallerieById(id);
                System.IO.File.Delete(Server.MapPath("/Images/ProductImages/" + gallery.ImageName));
                System.IO.File.Delete(Server.MapPath("/Images/ProductImages/Thumb/" + gallery.ImageName));
                _productGalleriesRepository.DeleteProductGallerie(gallery);
                return RedirectToAction("Gallery", new { id = gallery.ProductID });
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        #endregion


        #region  Featurs

        public ActionResult ProductFeaturs(int id)
        {
            try
            {
                ViewBag.Features = _productFeaturesRepository.GetAllProductFeatures().Where(f => f.ProductID == id).ToList();
                ViewBag.FeatureID = new SelectList(_featuresRepository.GetAllFeatures(), "FeatureID", "FeatureTitle");
                return View(new Product_Features()
                {
                    ProductID = id
                });
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        [HttpPost]
        public ActionResult ProductFeaturs(Product_Features feature)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _productFeaturesRepository.InsertProductFeature(feature);
                }
                return RedirectToAction("ProductFeaturs", new { id = feature.ProductID });
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        public void DeleteFeature(int id)
        {
            var feature = _productFeaturesRepository.GetProductFeatureById(id);
            _productFeaturesRepository.DeleteProductFeature(feature);
        }
        #endregion
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
