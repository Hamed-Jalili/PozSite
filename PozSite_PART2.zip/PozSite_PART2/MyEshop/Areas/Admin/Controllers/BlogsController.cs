﻿using DataLayer;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataLayer.Repositories;
using DataLayer.Services;
using DataLayer.ViewModels;
using MyEshop.Utilities;

namespace MyEshop.Areas.Admin.Controllers
{
    public class BlogsController : Controller
    {
        private IBlogRepository _blog;
        private IBlogGroupsRepository _blogGroups;
        asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        public BlogsController()
        {
            _blog = new BlogRepository(db);
            _blogGroups = new BlogGroupsRepository(db);
        }
        // GET: Admin/Blogs
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Blogs()
        {
            try
            {
                return View(_blog.GetAllBlogs().OrderByDescending(i => i.BlogID));
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        public ActionResult BlogAdder()
        {
            try
            {
                ViewBag.GroupID = new SelectList(_blogGroups.GetAllBlogGroups(), "GroupID", "GroupeTitle");
                return View();
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BlogAdder(BlogViewModels blog, HttpPostedFileBase imageBlog)
        {
            try
            {
                if (blog.GroupID == 0)
                {
                    ViewBag.ErrorGroupID = true;
                    ViewBag.GroupID = new SelectList(_blogGroups.GetAllBlogGroups(), "GroupID", "GroupeTitle", blog.GroupID);
                    return View(blog);
                }
                if (ModelState.IsValid)
                {
                    if (imageBlog != null && imageBlog.IsImage())
                    {
                        blog.MainImage = Guid.NewGuid().ToString() + Path.GetExtension(imageBlog.FileName);
                        imageBlog.SaveAs(Server.MapPath("/Images/BlogImages/" + blog.MainImage));
                        ImageResizer img = new ImageResizer();
                        img.Resize(Server.MapPath("/Images/BlogImages/" + blog.MainImage),
                            Server.MapPath("/Images/BlogImages/Thumb/" + blog.MainImage));
                    }
                    else
                    {
                        ModelState.AddModelError("MainImage", "لطفا عکس را وارد کنید");
                        ViewBag.GroupID = new SelectList(_blogGroups.GetAllBlogGroups(), "GroupID", "GroupeTitle", blog.GroupID);
                        return View(blog);
                    }
                    Blog addBlog = new Blog()
                    {
                        DatePosted = DateTime.Now,
                        Title = blog.Title,
                        HtmlBody = blog.HtmlBody,
                        MainImage = blog.MainImage,
                        IsSuggested = blog.IsSuggested,
                        GroupeId = blog.GroupID,
                    };
                    _blog.InsertBlog(addBlog);
                    return RedirectToAction("Blogs");
                }
                ViewBag.GroupID = new SelectList(_blogGroups.GetAllBlogGroups(), "GroupID", "GroupeTitle", blog.GroupID);
                return View(blog);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        public ActionResult BlogEditor(int id)
        {
            try
            {
                Blog blog = _blog.GetblogById(id);
                BlogViewModels viewBlog = new BlogViewModels()
                {
                    BlogID = blog.BlogID,
                    DatePosted = blog.DatePosted,
                    Title = blog.Title,
                    HtmlBody = blog.HtmlBody,
                    IsSuggested = blog.IsSuggested,
                    MainImage = blog.MainImage,
                    GroupID = blog.GroupeId
                };
                ViewBag.GroupID = new SelectList(_blogGroups.GetAllBlogGroups(), "GroupID", "GroupeTitle", blog.GroupeId);
                return View(viewBlog);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }
        [HttpPost]
        public ActionResult BlogEditor(BlogViewModels blog, HttpPostedFileBase imageBlog)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (imageBlog != null && imageBlog.IsImage())
                    {
                        if (blog.MainImage != "NoImg.svg")
                        {
                            System.IO.File.Delete(Server.MapPath("/Images/BlogImages/" + blog.MainImage));
                            System.IO.File.Delete(Server.MapPath("/Images/BlogImages/Thumb/" + blog.MainImage));
                        }
                        blog.MainImage = Guid.NewGuid().ToString() + Path.GetExtension(imageBlog.FileName);
                        imageBlog.SaveAs(Server.MapPath("/Images/BlogImages/" + blog.MainImage));
                        ImageResizer img = new ImageResizer();
                        img.Resize(Server.MapPath("/Images/BlogImages/" + blog.MainImage),
                            Server.MapPath("/Images/BlogImages/Thumb/" + blog.MainImage));
                    }
                    Blog addBlog = new Blog()
                    {
                        BlogID = blog.BlogID,
                        DatePosted = DateTime.Now,
                        Title = blog.Title,
                        HtmlBody = blog.HtmlBody,
                        MainImage = blog.MainImage,
                        IsSuggested = blog.IsSuggested,
                        GroupeId = blog.GroupID,
                    };
                    _blog.UpdateBlog(addBlog);
                    return RedirectToAction("Blogs");
                }
                ViewBag.GroupID = new SelectList(_blogGroups.GetAllBlogGroups(), "GroupID", "GroupeTitle", blog.GroupID);
                return View(blog);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }
        public ActionResult BlogDelete(int id)
        {
            try
            {
                Blog deleteBlog = _blog.GetblogById(id);
                bool delete = _blog.DeleteBlog(id);
                System.IO.File.Delete(Server.MapPath("/Images/BlogImages/" + deleteBlog.MainImage));
                System.IO.File.Delete(Server.MapPath("/Images/BlogImages/Thumb/" + deleteBlog.MainImage));
                if (delete)
                {
                    return Json(new { success = true, responseText = "حذف شد" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { success = false, responseText = "خطا در حذف لطفا دقت فرمایید" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json(new { success = false, responseText = "خطا در حذف لطفا دقت فرمایید" }, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult AdminBlogBlock()
        {
            return PartialView();
        }

        public ActionResult test()
        {
            return PartialView();
        }
    }
}