﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using DataLayer.Repositories;
using DataLayer.Services;

namespace MyEshop.Areas.Admin.Controllers
{
    public class DiscountController : Controller
    {
        asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private IDiscountRepository _discountRepository;
        public DiscountController()
        {
            _discountRepository = new DiscountRepository(db);
        }
        // GET: Admin/Discount
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(Discount discount)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (!_discountRepository.GetAllDiscounts().Any(u => u.Name == discount.Name))
                    {
                        _discountRepository.InsertDiscount(discount);
                        return View(discount);
                    }
                    else
                    {
                        ModelState.AddModelError("Name", "نام  تکراری است");
                        return View(discount);

                    }
                }
                return View(discount);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }
        public ActionResult Delete(int id)
        {
            try
            {
                _discountRepository.DeleteDiscount(id);
                return View("Index");
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }
        public ActionResult AllDiscount()
        {
            try
            {
                return PartialView(_discountRepository.GetAllDiscounts());
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }
    }
}