﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using DataLayer.Services;

namespace MyEshop.Areas.Admin.Controllers
{
    public class FeaturesController : Controller
    {
        private asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private IFeaturesRepository _featuresRepository;
        public FeaturesController()
        {
            _featuresRepository = new FeaturesRepository(db);
        }

        // GET: Admin/Features
        public ActionResult Index()
        {
            try
            {
                return View(_featuresRepository.GetAllFeatures());
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }

        // GET: Admin/Features/Details/5
        public ActionResult Details(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Features features = _featuresRepository.GetFeaturesById(id.Value);
                if (features == null)
                {
                    return HttpNotFound();
                }
                return View(features);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // GET: Admin/Features/Create
        public ActionResult Create()
        {
            return PartialView();
        }

        // POST: Admin/Features/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "FeatureID,FeatureTitle")] Features features)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _featuresRepository.InsertFeatures(features);
                    return RedirectToAction("Index");
                }
                return PartialView(features);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // GET: Admin/Features/Edit/5
        public ActionResult Edit(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Features features = _featuresRepository.GetFeaturesById(id.Value);
                if (features == null)
                {
                    return HttpNotFound();
                }
                return PartialView(features);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // POST: Admin/Features/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "FeatureID,FeatureTitle")] Features features)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _featuresRepository.UpdateFeatures(features);
                    return RedirectToAction("Index");
                }
                return PartialView(features);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }

        // GET: Admin/Features/Delete/5
        //public ActionResult Delete(int? id)
        //{
        //    try
        //    {
        //        if (id == null)
        //        {
        //            return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //        }
        //        Features features = _featuresRepository.GetFeaturesById(id.Value);
        //        if (features == null)
        //        {
        //            return HttpNotFound();
        //        }
        //        return View(features);
        //    }
        //    catch
        //    {
        //        return RedirectToAction("/ErrorPage/NotFound");
        //    }
        //}

        // POST: Admin/Features/Delete/5
        public ActionResult Delete(int id)
        {
            try
            {
                Features features = _featuresRepository.GetFeaturesById(id);
                _featuresRepository.DeleteFeatures(features);
                return RedirectToAction("Index");
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
                _featuresRepository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
