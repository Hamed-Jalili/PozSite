﻿using DataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataLayer.Repositories;
using DataLayer.Services;
using Config = DataLayer.MetaDataClasses.Config;

namespace MyEshop.Areas.Admin.Controllers
{
    public class ConfigController : Controller
    {

        private asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private IConfigRepository _config;
        public ConfigController()
        {
            _config = new ConfigRepository(db);
        }
        // GET: Admin/Config
        public ActionResult Contact()
        {
            return View(_config.SelectConfigById(1));
        }
        [HttpPost]
        public ActionResult Contact(Config config)
        {
            _config.UpdateConfig(config);
            return RedirectToAction("Contact");
        }
        public ActionResult About()
        {
            return View(_config.SelectConfigById(1));
        }
        [HttpPost]
        public ActionResult About(Config config)
        {
            _config.UpdateConfig(config);
            return RedirectToAction("About");
        }
        public ActionResult Policies()
        {
            return View(_config.SelectConfigById(1));
        }
        [HttpPost]
        public ActionResult Policies(Config config)
        {
            _config.UpdateConfig(config);
            return RedirectToAction("Policies");
        }
    }
}