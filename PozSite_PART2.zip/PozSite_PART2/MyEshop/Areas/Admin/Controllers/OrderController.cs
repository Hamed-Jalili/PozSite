﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using DataLayer.Repositories;
using DataLayer.Services;

namespace MyEshop.Areas.Admin.Controllers
{
    public class OrderController : Controller
    {
        asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private IOnlineOrderRepository _onlineOrderRepository;
        public OrderController()
        {
            _onlineOrderRepository = new OnlineOrderRepository(db);
        }
        // GET: Admin/Order
        public ActionResult Index()
        {
            return View();
        }

        public ViewResult Orders()
        {
            return View();
        }
        public void Delete(int id)
        {
            var Orders = _onlineOrderRepository.GetOnlineOrderById(id);
            _onlineOrderRepository.DeleteOnlineOrder(Orders);
        }
        public ActionResult OrderBlock()
        {
            try
            {
                return PartialView(_onlineOrderRepository.GetAllOnlineOrders().OrderByDescending(i => i.OrderID));
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }

    }
}