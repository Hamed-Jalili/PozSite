﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MyEshop.Areas.Admin.Controllers
{
    public class AddsController : Controller
    {
        // GET: Admin/Adds
        public ActionResult Index()
        {
            return View();
        }

        public ViewResult Adds()
        {
            return View();
        }

        public PartialViewResult AddBlock()
        {
            return PartialView();
        }
    }
}