﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataLayer;
using DataLayer.Repositories;
using DataLayer.Services;
using DataLayer.ViewModels;
using MyEshop.Utilities;

namespace MyEshop.Areas.Admin.Controllers
{
    public class AdvertController : Controller
    {
        asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private IAdRepository _adRepository;
        public AdvertController()
        {
            _adRepository = new AdRepository(db);
        }
        // GET: Admin/Advert
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Adverts()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Adverts(AdViewModels ad, HttpPostedFileBase Image)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (Image != null && Image.IsImage())
                    {
                        ad.Image = Guid.NewGuid().ToString() + Path.GetExtension(Image.FileName);
                        Image.SaveAs(Server.MapPath("/Images/Ad/" + ad.Image));
                    }
                    Ad addAd = new Ad()
                    {
                        Image = ad.Image,
                        Link = ad.Link,
                        PositionId = ad.PositionId
                    };
                    _adRepository.InsertAd(addAd);
                    return View(ad);
                }
                return View(ad);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }
        public ActionResult Delete(int id)
        {
            try
            {
                Ad deleteAd = _adRepository.GetAdById(id);
                System.IO.File.Delete(Server.MapPath("/Images/Ad/" + deleteAd.Image));
                _adRepository.DeleteAd(id);
                return RedirectToAction("Adverts");
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }
        public ActionResult AdvertBlock()
        {
            try
            {
                return PartialView(_adRepository.GetAllAds());
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }

        }
    }
}