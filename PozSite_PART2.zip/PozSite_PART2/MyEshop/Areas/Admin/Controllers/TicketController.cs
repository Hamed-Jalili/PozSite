﻿using DataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataLayer.Repositories;
using DataLayer.Services;
using DataLayer.ViewModels;

namespace MyEshop.Areas.Admin.Controllers
{
    public class TicketController : Controller
    {
        asamedc1_bazarjeEntities db = new asamedc1_bazarjeEntities();
        private ITicketRepository _ticket;
        private ITicketImageRepository _ticketImage;
        private IUsersRepository _users;

        public TicketController()
        {
            _ticket = new TicketRepository(db);
            _ticketImage = new TicketImageRepository(db);
            _users = new UsersRepository(db);

        }
        // GET: Admin/Ticket
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Tickets()
        {
            return View();
        }
        
        public ActionResult TicketBlock()
        {
            try
            {
                var ticket = _ticket.GetAllTicketNotAsnwer();
                return PartialView(_ticket.GetAllTicketNotAsnwer());
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        public ActionResult TicketView(int id)
        {
            try
            {
                Ticket ticket = _ticket.GetTicketById(id);
                TicketViewModel ticketViewModel = new TicketViewModel()
                {
                    Body = ticket.Body,
                    Email = ticket.Email,
                    Title = ticket.Title,
                    UserName = ticket.Users.UserName,
                    Image = _ticketImage.GetTicketImageByTicketId(ticket.TicketID)?.ImageName,
                    DateSubmited = ticket.DateSubmited,
                    UserID = ticket.UserID,
                    TicketID = ticket.TicketID,

                };
                return PartialView(ticketViewModel);
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
        public ActionResult AnsweredTicket(TicketViewModel ticket)
        {
            try
            {
                var user = _users.GetUserByUserName(User.Identity.Name);
                var selectTicketById = _ticket.GetTicketById(ticket.TicketID);
                Ticket addTicket = new Ticket()
                {
                    Body = ticket.Body,
                    Title = ticket.Title,
                    UserID = ticket.UserID,
                    Email = user.Email,
                    DateSubmited = DateTime.Now,
                    IsAnswered = true,
                    IsAdmin = true,
                };
                _ticket.InsertTicket(addTicket);
                selectTicketById.IsAnswered = true;
                _ticket.Save();
                return Redirect("Tickets");
            }
            catch
            {
                return RedirectToAction("/ErrorPage/NotFound");
            }
        }
    }
}